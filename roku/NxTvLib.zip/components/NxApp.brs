' NxTv para Roku - tela principal
function appVer() as string
    return "1.3.0"
end function

' cria um componente pelo nome; dentro da biblioteca de atualização o nome pode precisar do prefixo
function newNode(name as string) as object
    n = CreateObject("roSGNode", name)
    if n = invalid then n = CreateObject("roSGNode", "NxTvLib:" + name)
    return n
end function

function compName(name as string) as string
    t = CreateObject("roSGNode", name)
    if t = invalid then return "NxTvLib:" + name
    return name
end function

sub init()
    m.scene = m.top.getScene()
    m.reg = CreateObject("roRegistrySection", "NxTv")
    m.navList = m.top.findNode("navList")
    m.catList = m.top.findNode("catList")
    m.itemList = m.top.findNode("itemList")
    m.settingsList = m.top.findNode("settingsList")
    rowName = compName("RowItemL")
    m.navList.itemComponentName = rowName
    m.catList.itemComponentName = rowName
    m.itemList.itemComponentName = rowName
    m.settingsList.itemComponentName = rowName
    m.eventPanel = m.top.findNode("eventPanel")
    m.video = m.top.findNode("video")
    m.mainGroup = m.top.findNode("mainGroup")
    m.livePanel = m.top.findNode("livePanel")
    m.infoPanel = m.top.findNode("infoPanel")
    m.loading = m.top.findNode("loading")
    m.settings = m.top.findNode("settings")
    m.osd = m.top.findNode("osd")
    m.toast = m.top.findNode("toast")
    m.spinner = m.top.findNode("spinner")
    m.spinner.poster.uri = "pkg:/images/spinner.png"
    m.spinner.poster.width = 100
    m.spinner.poster.height = 100
    m.spinner.control = "start"

    m.sections = ["search", "live", "movie", "series", "fav", "events", "settings"]
    m.secTitles = { search: "RESULTADOS", live: "TV AO VIVO", movie: "FILMES", series: "SÉRIES", fav: "FAVORITOS", events: "EVENTOS DO DIA" }
    nav = CreateObject("roSGNode", "ContentNode")
    names = ["Pesquisa", "TV ao Vivo", "Filmes", "Séries", "Favoritos", "Eventos", "Configurações"]
    icons = ["search", "tv", "film", "series", "star", "ball", "gear"]
    for i = 0 to 6
        n = nav.createChild("ContentNode")
        n.title = names[i]
        n.hdPosterUrl = "pkg:/images/nav_" + icons[i] + ".png"
        n.addFields({ showLogo: true, compact: true })
    end for
    m.navList.content = nav

    m.sec = "live"
    m.zone = "nav"
    m.pos = { search: { c: 0, i: 0 }, live: { c: 1, i: 0 }, movie: { c: 0, i: 0 }, series: { c: 0, i: 0 }, fav: { c: 0, i: 0 }, events: { c: 0, i: 0 } }
    m.ridG = 0
    m.ridI = 0
    m.ridS = 0
    m.ridE = 0
    m.ser = invalid
    m.full = false
    m.fullKind = ""
    m.playItem = invalid
    m.liveItem = invalid
    m.unlocked = false
    m.query = ""
    m.firstItems = true
    m.loaded = false
    m.seenSent = false
    m.reqSec = ""
    m.reqCat = -1
    m.catsContent = invalid
    m.itemsContent = invalid

    m.lists = ParseJSON(regRead("lists", "[]"))
    if type(m.lists) <> "roArray" then m.lists = []
    m.activeId = regRead("active", "")
    m.pin = regRead("pin", "0000")
    m.order = regRead("order", "list")
    m.anti = regRead("anti", "normal")
    if m.anti <> "normal" and m.anti <> "forte" and m.anti <> "off" then m.anti = "normal"

    m.navList.observeField("itemFocused", "onNavFocus")
    m.navList.observeField("itemSelected", "onNavSelect")
    m.catList.observeField("itemFocused", "onCatFocus")
    m.catList.observeField("itemSelected", "onCatSelect")
    m.itemList.observeField("itemFocused", "onItemFocus")
    m.itemList.observeField("itemSelected", "onItemSelect")
    m.settingsList.observeField("itemSelected", "onSettingSelect")
    m.video.observeField("state", "onVideoState")
    m.video.observeField("position", "onVideoPos")

    m.top.findNode("clockTimer").observeField("fire", "updateClock")
    m.top.findNode("clockTimer").control = "start"
    m.top.findNode("toastTimer").observeField("fire", "hideToast")
    m.top.findNode("osdTimer").observeField("fire", "hideOsd")
    m.recT = CreateObject("roSGNode", "Timer")
    m.recT.duration = 10
    m.recT.repeat = false
    m.recT.observeField("fire", "onRecT")
    m.top.appendChild(m.recT)
    m.catTimer = m.top.findNode("catTimer")
    m.catTimer.observeField("fire", "onCatTimer")
    m.epgTimer = m.top.findNode("epgTimer")
    m.epgTimer.observeField("fire", "refreshEpg")
    m.loadTimer = m.top.findNode("loadTimer")
    m.loadTimer.observeField("fire", "onLoadWatch")
    m.okTimer = m.top.findNode("okTimer")
    m.okTimer.observeField("fire", "onBootOk")
    m.okTimer.control = "start"
    m.gotStatus = false
    m.loadTries = 0
    gdInit()
    updateClock()

    m.task = newNode("DataTaskL")
    m.task.observeField("status", "onStatus")
    m.task.observeField("outLoad", "onLoad")
    m.task.observeField("outGroups", "onGroups")
    m.task.observeField("outItems", "onItems")
    m.task.observeField("outSeries", "onSeries")
    m.task.observeField("outEpg", "onEpg")
    m.task.observeField("outUpd", "onUpd")
    m.task.observeField("outFind", "onFind")
    m.task.observeField("outVInfo", "onVInfo")
    m.vinfo = {}
    m.detIsOpen = false
    m.infoKey = ""
    m.isApi = false
    m.infoT = CreateObject("roSGNode", "Timer")
    m.infoT.duration = 0.5
    m.infoT.repeat = false
    m.infoT.observeField("fire", "onInfoT")
    m.top.appendChild(m.infoT)
    m.task.observeField("outScanReq", "onScanReq")
    m.scanTask = newNode("DataTaskL")
    m.scanTask.observeField("outScan", "onScan")
    m.scanTask.control = "RUN"
    m.preTask = newNode("DataTaskL")
    m.preTask.control = "RUN"
    m.task.control = "RUN"

    m.top.setFocus(true)
    if activeList() = invalid
        showLoading("Bem-vindo ao NxTv", "Vamos cadastrar a sua lista")
        startAddList()
    else
        startLoad(false)
    end if
end sub

sub onNotice()
    if m.top.notice <> "" then toast(m.top.notice)
end sub

sub onBootOk()
    regWrite("lib_try", "0")
    d = CreateObject("roDateTime")
    d.toLocalTime()
    today = d.asDateString("short-date")
    if regRead("upd_chk", "") <> today
        regWrite("upd_chk", today)
        m.updManual = false
        sendCmd({ c: "upd" })
    end if
end sub

' ---------------- atualização do app ----------------
function verNum(v as string) as integer
    p = v.split(".")
    n = 0
    for i = 0 to 2
        x = 0
        if i < p.count() then x = p[i].toInt()
        n = n * 1000 + x
    end for
    return n
end function

sub checkUpdate()
    m.updManual = true
    toast("Procurando atualização...")
    sendCmd({ c: "upd" })
end sub

sub onUpd()
    r = m.task.outUpd
    if r = invalid then return
    if r.ok <> true
        if m.updManual = true
            why = ""
            if r.err <> invalid then why = r.err
            toast("Não foi possível verificar: " + why)
        end if
        return
    end if
    if verNum(r.ver) <= verNum(appVer())
        if m.updManual = true then toast("Você já está na versão mais nova (" + appVer() + ")")
        return
    end if
    if m.updManual <> true
        toast("Nova versão " + r.ver + " em Configurações > Atualizar app")
        return
    end if
    m.updInfo = r
    showMsg("Atualizar o NxTv", ["Versão nova: " + r.ver, "O app vai reiniciar para usar a versão nova."], ["Atualizar agora", "Cancelar"], "upd")
end sub

sub applyUpdate()
    r = m.updInfo
    if r = invalid then return
    regWrite("upd_ver", r.ver)
    regWrite("upd_zip", r.zip)
    regWrite("upd_bad", "")
    regWrite("lib_try", "0")
    stopVideo()
    toast("Instalando a versão " + r.ver + "...")
    m.top.reloadReq = true
end sub

sub resetUpdate()
    regWrite("upd_ver", "")
    regWrite("upd_zip", "")
    stopVideo()
    toast("Voltando para a versão original...")
    m.top.reloadReq = true
end sub

sub onScanReq()
    r = m.task.outScanReq
    if r = invalid then return
    m.scanTask.cmd = r
end sub

sub onScan()
    r = m.scanTask.outScan
    if r = invalid then return
    sendCmd({ c: "evch", res: r.res })
    ' atualiza a lista de eventos aberta para mostrar os canais
    if m.sec = "events" and not m.full and m.ser = invalid then requestItems()
end sub

sub onFind()
    r = m.task.outFind
    m.finding = false
    if r = invalid or m.sec <> "events" then return
    if r.count = 0
        if m.findQ <> ""
            toast("Não achei o jogo na programação. Buscando " + chr(34) + m.findQ + chr(34) + "...")
            runSearch(m.findQ)
        else
            toast("Não achei o canal deste evento")
        end if
        return
    end if
    m.query = "evento"
    m.autoPlay = true
    m.navList.jumpToItem = 0
    requestGroups("search")
    setZone("items")
end sub

' ---------------- pesquisa direta (usada pelos eventos) ----------------
sub runSearch(txt as string)
    m.query = txt
    m.ser = invalid
    m.sec = "search"
    m.navList.jumpToItem = 0
    m.ridG = m.ridG + 1
    m.top.findNode("catTitle").text = "RESULTADOS"
    m.catList.content = infoContent("Buscando...")
    m.itemList.content = infoContent("")
    toast("Buscando " + chr(34) + txt + chr(34) + "...")
    sendCmd({ c: "search", q: txt, rid: m.ridG, unlocked: m.unlocked })
    setZone("cats")
end sub

' ---------------- utilitários ----------------
function regRead(k as string, def as string) as string
    v = m.reg.read(k)
    if v = "" then return def
    return v
end function

sub regWrite(k as string, v as string)
    m.reg.write(k, v)
    m.reg.flush()
end sub

sub saveLists()
    regWrite("lists", FormatJSON(m.lists))
    regWrite("active", m.activeId)
end sub

function activeList() as dynamic
    for each L in m.lists
        if L.id = m.activeId then return L
    end for
    if m.lists.count() > 0
        m.activeId = m.lists[0].id
        return m.lists[0]
    end if
    return invalid
end function

function f(node as object, name as string, def as dynamic) as dynamic
    if node = invalid then return def
    if node.hasField(name)
        v = node.getField(name)
        if v <> invalid then return v
    end if
    return def
end function

sub updateClock()
    d = CreateObject("roDateTime")
    d.toLocalTime()
    h = d.getHours()
    mi = d.getMinutes()
    hs = h.toStr()
    if h < 10 then hs = "0" + hs
    ms = mi.toStr()
    if mi < 10 then ms = "0" + ms
    m.top.findNode("clock").text = hs + ":" + ms
end sub

sub toast(msg as string)
    m.top.findNode("toastLbl").text = msg
    m.toast.visible = true
    t = m.top.findNode("toastTimer")
    t.control = "stop"
    t.control = "start"
end sub

sub hideToast()
    m.toast.visible = false
end sub

sub showLoading(title as string, sub1 as string)
    m.loading.visible = true
    m.top.findNode("loadTitle").text = title
    m.top.findNode("loadSub").text = sub1
    m.spinner.visible = true
    m.top.setFocus(true)
end sub

sub hideLoading()
    m.loading.visible = false
end sub

sub onStatus()
    s = m.task.status
    if s <> "" then m.gotStatus = true
    print "NxTv status: "; s
    if m.loading.visible
        if s <> "" then m.top.findNode("loadSub").text = s
    else if s <> "" and s.instr("Buscando") >= 0
        toast(s)
    end if
end sub

' ---------------- carregar lista ----------------
sub startLoad(force as boolean)
    stopVideo()
    L = activeList()
    if L = invalid
        openSettings()
        return
    end if
    m.loaded = false
    m.firstItems = true
    m.ser = invalid
    showLoading("Carregando lista", L.name)
    m.loadCmd = { c: "load", list: L, force: force, order: m.order }
    m.gotStatus = false
    m.loadTries = 0
    sendCmd(m.loadCmd)
    m.loadTimer.control = "stop"
    m.loadTimer.control = "start"
end sub

' se a tarefa não respondeu (pedido perdido ao ligar a TV), manda de novo
sub onLoadWatch()
    if m.loaded or not m.loading.visible or m.gotStatus then return
    m.loadTries = m.loadTries + 1
    print "NxTv: tarefa sem resposta, tentativa "; m.loadTries
    if m.loadTries <= 3
        sendCmd(m.loadCmd)
        m.loadTimer.control = "start"
    else
        m.spinner.visible = false
        showMsg("Erro ao carregar", ["A lista não respondeu.", "Verifique a internet e tente de novo."], ["Tentar novamente", "Configurações"], "loadErr")
    end if
end sub

sub onLoad()
    r = m.task.outLoad
    if r = invalid then return
    if r.ok <> true
        m.spinner.visible = false
        m.top.findNode("loadTitle").text = "Não foi possível carregar a lista"
        if r.msg <> invalid and r.msg.instr("Erro ao organizar") >= 0
            m.top.findNode("loadSub").text = r.msg
        else
            m.top.findNode("loadSub").text = "Verifique a internet e os dados da lista"
        end if
        showMsg("Erro ao carregar", ["Não foi possível carregar a lista.", "Verifique a internet e os dados da lista."], ["Tentar novamente", "Configurações"], "loadErr")
        return
    end if
    m.loaded = true
    hideLoading()
    m.isApi = (r.api = true)
    m.sec = "live"
    m.pos = { search: { c: 0, i: 0 }, live: { c: 1, i: 0 }, movie: { c: 0, i: 0 }, series: { c: 0, i: 0 }, fav: { c: 0, i: 0 }, events: { c: 0, i: 0 } }
    m.navList.jumpToItem = 1
    setZone("items")
    requestGroups("live")
end sub

' ---------------- pedidos à tarefa ----------------
sub sendCmd(c as object)
    if m.cmdSeq = invalid then m.cmdSeq = 0
    m.cmdSeq = m.cmdSeq + 1
    c.seq = m.cmdSeq
    m.task.cmd = c
end sub

sub requestGroups(sec as string)
    m.ridG = m.ridG + 1
    m.sec = sec
    m.top.findNode("catTitle").text = m.secTitles[sec]
    if sec = "events"
        m.catList.content = infoContent("Buscando os jogos de hoje...")
    else
        m.catList.content = infoContent("Carregando...")
    end if
    m.itemList.content = infoContent("")
    sendCmd({ c: "groups", sec: sec, rid: m.ridG, unlocked: m.unlocked })
end sub

sub requestItems()
    m.ridI = m.ridI + 1
    m.reqSec = m.sec
    m.reqCat = m.pos[m.sec].c
    m.catTimer.control = "stop"
    m.itemList.content = infoContent("Carregando...")
    sendCmd({ c: "items", sec: m.sec, cat: m.pos[m.sec].c, rid: m.ridI, unlocked: m.unlocked })
end sub

function infoContent(msg as string) as object
    root = CreateObject("roSGNode", "ContentNode")
    root.addFields({ placeholder: true, kind: "" })
    if msg <> ""
        n = root.createChild("ContentNode")
        n.title = msg
        n.addFields({ info: true })
    end if
    return root
end function

sub onGroups()
    node = m.task.outGroups
    if node = invalid or f(node, "rid", -1) <> m.ridG then return
    m.catsContent = node
    if node.getChildCount() = 0
        msg = "Nada aqui"
        if m.sec = "search" then msg = "Pressione OK em Pesquisa"
        if m.sec = "events"
            msg = "Nenhum evento hoje"
            if f(node, "err", false) then msg = "Sem conexão com os eventos"
        end if
        m.catList.content = infoContent(msg)
        m.itemList.content = infoContent("")
        return
    end if
    m.catList.content = node
    c = m.pos[m.sec].c
    if m.sec = "search"
        c = 0
        for i = 0 to node.getChildCount() - 1
            if node.getChild(i).shortDescriptionLine1 <> "(0)"
                c = i
                exit for
            end if
        end for
        m.pos.search.c = c
        m.pos.search.i = 0
    end if
    if c >= node.getChildCount() then c = 0
    m.catList.jumpToItem = c
    m.pos[m.sec].c = c
    requestItems()
end sub

sub onItems()
    node = m.task.outItems
    if node = invalid or f(node, "rid", -1) <> m.ridI then return
    m.itemsContent = node
    title = ""
    if m.catsContent <> invalid and m.pos[m.sec].c < m.catsContent.getChildCount() then title = m.catsContent.getChild(m.pos[m.sec].c).title
    m.top.findNode("itemTitle").text = ucase(title)
    if f(node, "locked", false)
        m.itemList.content = infoContent("Categoria bloqueada. Pressione OK e digite a senha.")
        m.itemsContent = invalid
        updateCount()
        updateSide()
        return
    end if
    if node.getChildCount() = 0
        msg = "Nada aqui."
        if m.sec = "fav" then msg = "Use o botão * para favoritar."
        if m.sec = "search" then msg = "Nenhum resultado."
        if m.sec = "events" then msg = "Nenhum evento nesta categoria."
        m.itemList.content = infoContent(msg)
        m.itemsContent = invalid
        updateCount()
        updateSide()
        return
    end if
    i = m.pos[m.sec].i
    if i >= node.getChildCount() then i = 0
    m.itemList.content = node
    ' primeira abertura: volta para o último canal assistido
    if m.firstItems and m.sec = "live"
        m.firstItems = false
        last = regRead("last", "")
        if last <> ""
            for k = 0 to node.getChildCount() - 1
                if f(node.getChild(k), "surl", "") = last
                    i = k
                    it = node.getChild(k)
                    if not f(it, "locked", false) then playPreview(it)
                    exit for
                end if
            end for
        end if
    end if
    m.itemList.jumpToItem = i
    m.pos[m.sec].i = i
    updateCount()
    updateSide()
    if m.autoPlay = true and m.sec = "search"
        m.autoPlay = false
        first = node.getChild(0)
        if first <> invalid and f(first, "kind", "") = "live" and not f(first, "locked", false)
            setZone("items")
            playPreview(first)
            goFull()
            extra = ""
            if node.getChildCount() > 1 then extra = " · ▲▼ outros " + (node.getChildCount() - 1).toStr() + " canais"
            toast("Passando em " + first.title + extra)
        end if
    end if
end sub

' ---------------- navegação ----------------
' a coluna em uso fica mais larga (as três somam sempre 1240 px)
sub colLayout(z as string)
    w = [260, 330, 610]
    if z = "nav" then w = [300, 380, 520]
    if z = "cats" then w = [260, 540, 400]
    if m.colW <> invalid
        if m.colW[0] = w[0] and m.colW[1] = w[1] then return
    end if
    m.colW = w
    x0 = 30
    x1 = x0 + w[0] + 20
    x2 = x1 + w[1] + 20
    t = m.top
    t.findNode("navBg").translation = [x0, 130]
    t.findNode("navBg").width = w[0]
    m.navList.translation = [x0, 150]
    m.navList.itemSize = [w[0], 80]
    t.findNode("catBg").translation = [x1, 130]
    t.findNode("catBg").width = w[1]
    t.findNode("catTitle").translation = [x1 + 24, 140]
    t.findNode("catTitle").width = w[1] - 40
    m.catList.translation = [x1, 196]
    m.catList.itemSize = [w[1], 66]
    t.findNode("itemBg").translation = [x2, 130]
    t.findNode("itemBg").width = w[2]
    t.findNode("itemTitle").translation = [x2 + 24, 140]
    t.findNode("itemTitle").width = w[2] - 50
    m.itemList.translation = [x2, 196]
    m.itemList.itemSize = [w[2], 66]
    t.findNode("itemCount").translation = [x2, 1005]
    t.findNode("itemCount").width = w[2] - 24
end sub

sub setZone(z as string)
    m.zone = z
    colLayout(z)
    if z = "nav" then m.navList.setFocus(true)
    if z = "cats" then m.catList.setFocus(true)
    if z = "items" then m.itemList.setFocus(true)
end sub

sub onNavFocus()
    if not m.loaded then return
    idx = m.navList.itemFocused
    sec = m.sections[idx]
    if sec = "settings" then return
    if m.ser <> invalid then m.ser = invalid
    if sec = "search"
        if m.query = ""
            m.sec = "search"
            m.top.findNode("catTitle").text = "PESQUISA"
            m.catList.content = infoContent("Pressione OK para pesquisar")
            m.itemList.content = infoContent("")
            m.itemsContent = invalid
            updateSide()
            return
        end if
    end if
    if sec <> m.sec or m.catsContent = invalid or sec = "events" then requestGroups(sec)
end sub

sub onNavSelect()
    idx = m.navList.itemSelected
    sec = m.sections[idx]
    if sec = "settings"
        openSettings()
    else if sec = "search"
        openSearch()
    else
        setZone("cats")
    end if
end sub

sub onCatFocus()
    idx = m.catList.itemFocused
    if m.ser <> invalid
        showSeason(idx)
        return
    end if
    if m.zone <> "cats" then return
    if m.catsContent = invalid or f(m.catList.content, "placeholder", false) then return
    if m.sec = m.reqSec and idx = m.reqCat then return
    m.pos[m.sec].c = idx
    m.pos[m.sec].i = 0
    m.catTimer.control = "stop"
    m.catTimer.control = "start"
end sub

sub onCatTimer()
    requestItems()
end sub

sub onCatSelect()
    if m.ser <> invalid
        setZone("items")
        return
    end if
    if m.sec = "search" and m.query = ""
        openSearch()
        return
    end if
    if m.catsContent = invalid then return
    g = m.catsContent.getChild(m.catList.itemSelected)
    if g = invalid then return
    if f(g, "adult", false) and not m.unlocked
        askPin("cats")
        return
    end if
    setZone("items")
end sub

sub onItemFocus()
    idx = m.itemList.itemFocused
    if m.ser <> invalid
        m.ser.i = idx
    else
        m.pos[m.sec].i = idx
    end if
    updateCount()
    updateSide()
end sub

function curItem() as dynamic
    c = m.itemList.content
    if c = invalid or f(c, "placeholder", false) then return invalid
    i = m.itemList.itemFocused
    if i < 0 or i >= c.getChildCount() then return invalid
    return c.getChild(i)
end function

sub updateCount()
    c = m.itemList.content
    lbl = m.top.findNode("itemCount")
    if c = invalid or f(c, "placeholder", false)
        lbl.text = ""
        return
    end if
    lbl.text = (m.itemList.itemFocused + 1).toStr() + " / " + c.getChildCount().toStr()
end sub

sub onItemSelect()
    c = m.itemList.content
    if c = invalid then return
    if f(c, "placeholder", false)
        if m.top.findNode("itemTitle").text <> "" and m.catsContent <> invalid
            g = m.catsContent.getChild(m.pos[m.sec].c)
            if g <> invalid and f(g, "adult", false) and not m.unlocked then askPin("cats")
        end if
        return
    end if
    it = c.getChild(m.itemList.itemSelected)
    if it = invalid then return
    if f(it, "locked", false)
        askPin("item")
        return
    end if
    kind = f(it, "kind", "")
    if kind = "live"
        if m.playItem <> invalid and f(m.playItem, "surl", "") = f(it, "surl", "") and m.video.state <> "error" and m.video.state <> "stopped"
            goFull()
        else
            playPreview(it)
        end if
    else if kind = "movie"
        playVod(it)
    else if kind = "series"
        openSeries(it)
    else if kind = "ep"
        playVod(it)
    else if kind = "event"
        if not m.loaded
            toast("Carregue uma lista para procurar os canais")
            return
        end if
        if m.finding = true then return
        m.finding = true
        m.findQ = f(it, "q", "")
        label = it.title
        if f(it, "scanState", "") = "wait" and m.task.outScanReq <> invalid
            m.finding = false
            toast("Ainda procurando os canais dos jogos... espere uns segundos")
            return
        end if
        ev = { home: f(it, "home", ""), away: f(it, "away", ""), hfull: f(it, "hfull", ""), afull: f(it, "afull", ""), title: f(it, "title0", it.title), tsec: f(it, "tsec", 0), league: f(it, "league", "") }
        m.ridF = m.ridG + 1000
        toast("Procurando o canal do jogo...")
        sendCmd({ c: "evfind", ev: ev, label: label, rid: m.ridF, unlocked: m.unlocked, evKey: f(it, "evKey", "") })
    end if
end sub

' ---------------- painel da direita ----------------
sub updateSide()
    it = curItem()
    kind = ""
    if it <> invalid then kind = f(it, "kind", "")
    if it = invalid and m.itemList.content <> invalid then kind = f(m.itemList.content, "kind", "")
    if m.ser <> invalid then kind = "ep"
    if m.sec = "events"
        m.livePanel.visible = false
        m.infoPanel.visible = false
        m.eventPanel.visible = true
        if not m.full and m.playItem <> invalid then stopVideo()
        showEvent(it)
        m.top.findNode("hints").text = "OK: abrir o canal que está passando o jogo" + chr(10) + "Horários de Brasília · placar atualiza ao abrir a aba"
        return
    end if
    m.eventPanel.visible = false
    live = (kind = "live" or kind = "")
    m.livePanel.visible = live
    m.infoPanel.visible = not live
    if not live and not m.full and m.playItem <> invalid and f(m.playItem, "kind", "") = "live" then stopVideo()
    if live and not m.full and m.playItem = invalid and m.liveItem <> invalid and m.loaded then playPreview(m.liveItem)
    h = ""
    if live
        h = "OK: assistir · OK de novo: tela cheia" + chr(10) + "Setas: menu, categorias e canais" + chr(10) + "Botão *: favoritar, pesquisar e configurações"
    else if kind = "movie"
        h = "OK: assistir o filme" + chr(10) + "Direita: sinopse em tela cheia" + chr(10) + "Botão *: favoritar, pesquisar e configurações"
    else if kind = "series"
        h = "OK: ver temporadas e episódios" + chr(10) + "Direita: sinopse em tela cheia" + chr(10) + "Botão *: favoritar, pesquisar e configurações"
    else
        h = "OK: assistir o episódio · Direita: sinopse" + chr(10) + "Marca verde: episódio já assistido" + chr(10) + "Esquerda: temporadas · Voltar: séries"
    end if
    m.top.findNode("hints").text = h
    if not live
        name = ""
        meta = ""
        poster = ""
        gen = ""
        ikey = ""
        if it <> invalid
            if f(it, "locked", false)
                name = "Conteúdo adulto"
                meta = "Bloqueado por senha"
            else
                name = it.title
                poster = it.hdPosterUrl
                meta = ""
                if kind = "series" and it.shortDescriptionLine1 <> "" then meta = it.shortDescriptionLine1
                ikey = ""
                if kind = "movie" then ikey = "m:" + f(it, "surl", "")
                if kind = "series" then ikey = "s:" + lcase(f(it, "sname", it.title))
                gen = f(it, "grp", "")
                if kind = "ep"
                    name = f(it, "epLabel", "") + " — " + it.title
                    if f(it, "se", 0) > 0 then name = "T" + f(it, "se", 0).toStr() + " · " + name
                    meta = f(it, "sname", "")
                    if f(it, "dim", false) then meta = meta + " · Já assistido"
                    ikey = "s:" + lcase(f(it, "sname", ""))
                    gen = ""
                    if poster = "" and m.ser <> invalid then poster = m.ser.poster
                end if
            end if
        end if
        if it = invalid or f(it, "locked", false)
            ikey = ""
            gen = ""
        end if
        m.infoKey = ikey
        plot = ""
        line = ""
        inf = invalid
        if ikey <> "" then inf = m.vinfo[ikey]
        if inf <> invalid
            if inf.genre <> "" then gen = inf.genre
            line = inf.line
            plot = inf.plot
            if plot = "" and inf.ok then plot = "Sem sinopse"
        else if ikey <> "" and ikey <> "m:" and m.isApi
            plot = "Carregando sinopse..."
            m.infoWant = { key: ikey, kind: kind, surl: f(it, "surl", ""), sidx: f(it, "sidx", -1), seriesId: f(it, "seriesId", ""), sname: f(it, "sname", it.title) }
            m.infoT.control = "stop"
            m.infoT.control = "start"
        end if
        if line <> ""
            if meta <> "" then meta = line + " · " + meta else meta = line
        end if
        m.top.findNode("infoName").text = name
        m.top.findNode("infoGenre").text = gen
        m.top.findNode("infoMeta").text = meta
        m.top.findNode("infoPlot").text = plot
        m.top.findNode("infoMore").visible = (plot.len() > 230)
        m.top.findNode("infoPoster").uri = poster
    end if
end sub

sub onInfoT()
    w = m.infoWant
    if w = invalid or w.key <> m.infoKey then return
    if w.key.left(2) = "s:" then w.kind = "series"
    sendCmd({ c: "vinfo", key: w.key, kind: w.kind, surl: w.surl, sidx: w.sidx, seriesId: w.seriesId, sname: w.sname })
end sub

sub onVInfo()
    r = m.task.outVInfo
    if r = invalid or r.key = invalid then return
    m.vinfo[r.key] = r
    if r.key = m.infoKey then updateSide()
    if m.detIsOpen then detFill()
end sub

sub showEvent(it as dynamic)
    t = m.top
    if it = invalid or f(it, "kind", "") <> "event"
        t.findNode("evLeague").text = ""
        t.findNode("evLeagueLogo").uri = ""
        t.findNode("evHomeLogo").uri = ""
        t.findNode("evAwayLogo").uri = ""
        t.findNode("evHome").text = ""
        t.findNode("evAway").text = ""
        t.findNode("evCenter").text = ""
        t.findNode("evTitle").text = "Escolha um evento"
        t.findNode("evInfo").text = ""
        return
    end if
    t.findNode("evLeague").text = f(it, "league", "")
    t.findNode("evLeagueLogo").uri = f(it, "llogo", "")
    home = f(it, "home", "")
    st = f(it, "state", "pre")
    hm = f(it, "num", "")
    if home <> ""
        t.findNode("evHomeLogo").uri = f(it, "hlogoBig", "")
        t.findNode("evAwayLogo").uri = f(it, "alogoBig", "")
        t.findNode("evHome").text = home
        t.findNode("evAway").text = f(it, "away", "")
        if st = "pre"
            t.findNode("evCenter").text = hm
        else
            t.findNode("evCenter").text = f(it, "hscore", "") + " x " + f(it, "ascore", "")
        end if
        t.findNode("evTitle").text = f(it, "evTitle", "")
    else
        t.findNode("evHomeLogo").uri = f(it, "llogoBig", "")
        t.findNode("evAwayLogo").uri = ""
        t.findNode("evHome").text = ""
        t.findNode("evAway").text = ""
        t.findNode("evCenter").text = hm
        t.findNode("evTitle").text = f(it, "evTitle", "")
    end if
    info = "Começa às " + hm
    if st = "in" then info = "AO VIVO · " + f(it, "detail", "")
    if st = "post" then info = "Encerrado"
    sb = f(it, "subt", "")
    if sb <> "" then info = info + chr(10) + sb
    vn = f(it, "venue", "")
    if vn <> "" then info = info + chr(10) + vn
    ca = f(it, "chAll", "")
    if ca <> ""
        info = info + chr(10) + "Onde passa: " + ca
    else if f(it, "scanState", "") = "wait"
        info = info + chr(10) + "Procurando o canal na programação..."
    else
        info = info + chr(10) + "Canal não encontrado na programação"
    end if
    t.findNode("evInfo").text = info
end sub

sub updateNow(it as object)
    m.top.findNode("nowName").text = it.title
    num = f(it, "num", "")
    meta = f(it, "grp", "")
    if num <> "" then meta = meta + " · Canal " + num
    m.top.findNode("nowMeta").text = meta
    m.top.findNode("nowLogo").uri = it.hdPosterUrl
    m.top.findNode("osdNum").text = num
    m.top.findNode("osdName").text = it.title
    m.top.findNode("osdGroup").text = f(it, "grp", "")
    m.top.findNode("epgTime").text = ""
    m.top.findNode("epgNow").text = "Carregando programação..."
    m.top.findNode("epgBar").width = 0
    m.top.findNode("epgNext").text = ""
    m.top.findNode("osdEpg").text = ""
    requestEpg()
end sub

sub requestEpg()
    it = m.liveItem
    if it = invalid then return
    sid = f(it, "sid", "")
    if sid = ""
        m.top.findNode("epgNow").text = ""
        m.top.findNode("epgNext").text = "Programação não disponível para esta lista"
        return
    end if
    m.ridE = m.ridE + 1
    sendCmd({ c: "epg", sid: sid, rid: m.ridE })
    m.epgTimer.control = "start"
end sub

sub refreshEpg()
    if m.liveItem <> invalid and m.loaded then requestEpg()
end sub

sub onEpg()
    r = m.task.outEpg
    if r = invalid or r.rid <> m.ridE then return
    if r.ok
        m.top.findNode("epgTime").text = "AGORA  " + r.time
        m.top.findNode("epgNow").text = r.now
        w = Int(560 * r.pct)
        if w < 0 then w = 0
        if w > 560 then w = 560
        m.top.findNode("epgBar").width = w
        m.top.findNode("osdEpg").text = "Agora: " + r.now + " · " + r.time
    else
        m.top.findNode("epgTime").text = ""
        m.top.findNode("epgNow").text = "Sem informação do programa atual"
        m.top.findNode("epgBar").width = 0
        m.top.findNode("osdEpg").text = ""
    end if
    if r.nxt <> "" then m.top.findNode("epgNext").text = "A SEGUIR  " + r.nxt else m.top.findNode("epgNext").text = ""
end sub

' ---------------- vídeo ----------------
function fmtOf(url as string) as string
    u = lcase(url)
    q = u.instr("?")
    if q > 0 then u = u.left(q)
    if u.right(5) = ".m3u8" then return "hls"
    if u.right(4) = ".mp4" or u.right(4) = ".m4v" or u.right(4) = ".mov" then return "mp4"
    if u.right(4) = ".mkv" then return "mkv"
    return ""
end function

function urlKind(url as string) as string
    u = lcase(url)
    q = u.instr("?")
    if q > 0 then u = u.left(q)
    if u.right(5) = ".m3u8" then return "m3u8"
    if u.right(3) = ".ts" then return "ts"
    return ""
end function

sub startAttempt()
    a = m.attempts[m.attemptIdx]
    m.gd.armed = false
    m.gd.last = -1
    m.gd.moved = false
    m.gd.bufAt = 0
    m.gd.startAt = UpTime(0)
    m.gd.lastAt = m.gd.startAt
    c = CreateObject("roSGNode", "ContentNode")
    c.url = a
    fm = fmtOf(a)
    if fm <> "" then c.streamFormat = fm
    c.title = m.playItem.title
    if f(m.playItem, "kind", "") = "live" then c.live = true
    if m.fullKind = "vod" and m.resumeAt <> invalid and m.resumeAt > 0 then c.PlayStart = m.resumeAt
    m.video.content = c
    m.video.control = "play"
    ' se não começar a tocar em 8 s, tenta o outro formato
    if m.attTimer = invalid
        m.attTimer = CreateObject("roSGNode", "Timer")
        m.attTimer.repeat = false
        m.attTimer.observeField("fire", "onAttTimeout")
        m.top.appendChild(m.attTimer)
    end if
    m.attTimer.control = "stop"
    if m.attemptIdx + 1 < m.attempts.count() and f(m.playItem, "kind", "") = "live"
        m.attTimer.duration = 8
        m.attTimer.control = "start"
    end if
end sub

sub onAttTimeout()
    if m.playItem = invalid or m.video.state = "playing" then return
    if m.attemptIdx + 1 < m.attempts.count()
        m.attemptIdx = m.attemptIdx + 1
        startAttempt()
    end if
end sub

sub playItemNode(it as object)
    m.playItem = it
    m.attempts = [f(it, "surl", "")]
    alt = f(it, "salt", "")
    if alt <> "" then m.attempts.push(alt)
    ' canal ao vivo: começa pelo formato que funcionou da última vez
    if f(it, "kind", "") = "live" and m.attempts.count() = 2
        if m.liveFmt = invalid then m.liveFmt = regRead("livefmt", "")
        if m.liveFmt <> "" and urlKind(m.attempts[1]) = m.liveFmt and urlKind(m.attempts[0]) <> m.liveFmt then m.attempts = [m.attempts[1], m.attempts[0]]
    end if
    m.attemptIdx = 0
    m.seenSent = false
    gdReset(f(it, "surl", ""))
    startAttempt()
end sub

sub placeVideo()
    if m.full
        m.video.translation = [0, 0]
        m.video.width = 1920
        m.video.height = 1080
    else
        m.video.translation = [1370, 134]
        m.video.width = 440
        m.video.height = 248
    end if
end sub

sub playPreview(it as object)
    m.liveItem = it
    m.video.enableUI = false
    placeVideo()
    m.video.visible = true
    m.top.findNode("previewMsg").text = "Carregando..."
    playItemNode(it)
    regWrite("last", f(it, "surl", ""))
    updateNow(it)
    if m.full
        showOsd()
        recLiveWatch()
    end if
end sub

sub stopVideo()
    m.gdRT.control = "stop"
    m.gd.waiting = false
    m.gd.armed = false
    m.video.control = "stop"
    m.video.visible = false
    m.playItem = invalid
    m.top.findNode("previewMsg").text = "Selecione um canal"
end sub

sub onVideoState()
    st = m.video.state
    msgLbl = m.top.findNode("previewMsg")
    if st = "playing"
        msgLbl.text = ""
        if m.attTimer <> invalid then m.attTimer.control = "stop"
        gdPlaying()
        if m.playItem <> invalid and f(m.playItem, "kind", "") = "live"
            fmNow = urlKind(m.attempts[m.attemptIdx])
            if fmNow <> "" and fmNow <> m.liveFmt
                m.liveFmt = fmNow
                regWrite("livefmt", fmNow)
            end if
        end if
    else if st = "buffering"
        if not m.full then msgLbl.text = "Carregando..."
        if m.gd.armed and m.gd.bufAt = 0 then m.gd.bufAt = UpTime(0)
    else if st = "error"
        if m.playItem <> invalid and m.attemptIdx + 1 < m.attempts.count()
            m.attemptIdx = m.attemptIdx + 1
            startAttempt()
            return
        end if
        if gdOnError() then return ' estava funcionando e caiu: continua tentando
        playFailed()
    else if st = "finished"
        ' filme/episódio que "acaba" antes da hora é queda de conexão: reconecta e continua
        if m.fullKind = "vod" and m.gd.last > 5 and m.video.duration > 0 and m.gd.last < m.video.duration - 60
            if gdOnError() then return
        end if
        if m.fullKind = "vod"
            if m.playItem <> invalid then resDel(resKey(m.playItem))
            markSeen()
            if not nextEpisode() then closeFull()
        end if
    end if
end sub

sub playFailed()
    m.top.findNode("previewMsg").text = "Canal indisponível"
    m.video.visible = false
    toast("Não foi possível abrir este conteúdo")
    if m.full and m.fullKind = "vod" then closeFull()
end sub

' ---------------- antitravamento ----------------
' Vigia o vídeo depois que ele começa: se a imagem parar (posição não anda) ou o carregamento ficar
' preso, reconecta sozinho. Alterna o formato (.ts/.m3u8) se travar de novo, volta ao ponto certo em
' filmes e episódios e espera a internet voltar.
function atCfg() as object
    if m.anti = "forte" then return { liveFreeze: 7, vodFreeze: 15, liveBuf: 12, vodBuf: 25, conn: 15, max: 12 }
    return { liveFreeze: 10, vodFreeze: 20, liveBuf: 15, vodBuf: 30, conn: 20, max: 6 }
end function

sub gdInit()
    m.gd = { waiting: false, n: 0, url: "", okUrl: "", last: -1, lastAt: 0, bufAt: 0, startAt: 0, moved: false, armed: false, recAt: 0, offline: false, reco: 0 }
    m.devInfo = CreateObject("roDeviceInfo")
    m.gdT = CreateObject("roSGNode", "Timer")
    m.gdT.duration = 2
    m.gdT.repeat = true
    m.gdT.observeField("fire", "gdTick")
    m.top.appendChild(m.gdT)
    m.gdRT = CreateObject("roSGNode", "Timer")
    m.gdRT.repeat = false
    m.gdRT.observeField("fire", "gdRetryFire")
    m.top.appendChild(m.gdRT)
    m.gdT.control = "start"
end sub

' play novo escolhido pelo usuário: zera o contador
sub gdReset(url as string)
    m.gdRT.control = "stop"
    m.gd.waiting = false
    m.gd.n = 0
    m.gd.url = url
    m.gd.okUrl = ""
    m.gd.reco = 0
end sub

sub gdPlaying()
    if m.playItem = invalid then return
    m.gd.armed = true
    m.gd.okUrl = f(m.playItem, "surl", "")
    m.gd.bufAt = 0
    m.gd.lastAt = UpTime(0)
    if m.gd.reco > 0
        m.gd.reco = 0
        toast("Reconectado")
    end if
end sub

function gdVod() as boolean
    return m.fullKind = "vod"
end function

sub gdTick()
    if m.playItem = invalid or m.anti = "off" then return
    t = UpTime(0)
    if not m.devInfo.GetLinkStatus()
        if not m.gd.offline
            m.gd.offline = true
            toast("Sem internet · aguardando a conexão voltar")
        end if
        m.gd.lastAt = t
        m.gd.startAt = t
        return
    end if
    if m.gd.offline
        m.gd.offline = false
        if m.gd.okUrl = f(m.playItem, "surl", "")
            m.gdRT.control = "stop"
            m.gd.waiting = false
            toast("Internet voltou · reconectando")
            if gdVod() and m.gd.last > 5 then m.resumeAt = Int(m.gd.last)
            m.gd.reco = 1
            startAttempt()
        end if
        return
    end if
    cf = atCfg()
    vod = gdVod()
    ' reconexão que não engrena (nem toca nem dá erro)
    if not m.gd.armed
        lim = cf.conn
        if vod then lim = cf.conn * 2
        if m.gd.okUrl = f(m.playItem, "surl", "") and not m.gd.waiting and t - m.gd.startAt > lim
            if m.attemptIdx + 1 < m.attempts.count()
                m.attemptIdx = m.attemptIdx + 1
                startAttempt()
            else if not gdOnError()
                m.video.control = "stop"
                playFailed()
            end if
        end if
        return
    end if
    st = m.video.state
    if st = "paused"
        m.gd.lastAt = t
        m.gd.bufAt = 0
        return
    end if
    if st <> "playing" and st <> "buffering" then return
    vp = m.video.position
    if st = "playing" and vp <> m.gd.last
        if m.gd.last >= 0 then m.gd.moved = true
        m.gd.last = vp
        m.gd.lastAt = t
        if m.gd.n > 0 and t - m.gd.recAt > 60 then m.gd.n = 0 ' 1 min sem travar: zera o contador
        return
    end if
    still = t - m.gd.lastAt
    bufd = 0
    if m.gd.bufAt > 0 then bufd = t - m.gd.bufAt
    fl = cf.liveFreeze
    bl = cf.liveBuf
    if vod
        fl = cf.vodFreeze
        bl = cf.vodBuf
    end if
    if (m.gd.moved and still >= fl) or bufd >= bl then gdRescue()
end sub

sub gdRescue()
    it = m.playItem
    if it = invalid then return
    cf = atCfg()
    url = f(it, "surl", "")
    if m.gd.url <> url
        m.gd.url = url
        m.gd.n = 0
    end if
    m.gd.n = m.gd.n + 1
    m.gd.recAt = UpTime(0)
    vod = gdVod()
    if m.gd.n > cf.max
        m.gd.armed = false
        toast("Não foi possível recuperar. Tente de novo ou escolha outro.")
        if vod
            closeFull()
        else
            m.video.control = "stop"
            m.video.visible = false
            m.top.findNode("previewMsg").text = "O canal parou de responder"
        end if
        return
    end if
    ' travou de novo: troca o formato (.ts / .m3u8)
    if not vod and m.gd.n mod 2 = 0 and m.attempts.count() > 1 then m.attemptIdx = (m.attemptIdx + 1) mod m.attempts.count()
    if vod
        if m.gd.last > 5 then m.resumeAt = Int(m.gd.last)
        toast("O vídeo travou · reconectando...")
    else
        toast("Sinal travou · reconectando (" + m.gd.n.toStr() + "/" + cf.max.toStr() + ")")
    end if
    m.gd.reco = m.gd.n
    m.video.control = "stop"
    startAttempt()
end sub

' canal/filme que estava funcionando e caiu de vez: tenta de novo com intervalo crescente
function gdOnError() as boolean
    if m.anti = "off" or m.playItem = invalid then return false
    url = f(m.playItem, "surl", "")
    if m.gd.okUrl <> url then return false
    cf = atCfg()
    if m.gd.url <> url
        m.gd.url = url
        m.gd.n = 0
    end if
    if m.gd.offline
        msg = "Sem internet · aguardando a conexão voltar"
    else
        m.gd.n = m.gd.n + 1
        if m.gd.n > cf.max then return false
        msg = ""
    end if
    if gdVod() and m.gd.last > 5 then m.resumeAt = Int(m.gd.last)
    w = 2 * m.gd.n
    if w < 2 then w = 2
    if w > 15 then w = 15
    if msg = "" then msg = "Sinal caiu · reconectando em " + w.toStr() + " s (" + m.gd.n.toStr() + "/" + cf.max.toStr() + ")"
    m.gd.armed = false
    m.attemptIdx = 0
    m.top.findNode("previewMsg").text = msg
    toast(msg)
    m.gdRT.control = "stop"
    m.gdRT.duration = w
    m.gdRT.control = "start"
    m.gd.waiting = true
    return true
end function

sub gdRetryFire()
    if m.playItem = invalid or f(m.playItem, "surl", "") <> m.gd.url then return
    if not m.devInfo.GetLinkStatus()
        m.gdRT.control = "start" ' sem internet: espera sem gastar tentativa
        return
    end if
    m.gd.waiting = false
    m.gd.reco = m.gd.n
    startAttempt()
end sub

sub onVideoPos()
    if m.fullKind = "vod" and m.playItem <> invalid and m.video.state = "playing"
        vp = m.video.position
        if m.lastResSave = invalid then m.lastResSave = 0
        if abs(vp - m.lastResSave) >= 10
            m.lastResSave = vp
            resSave(m.playItem, vp, m.video.duration)
        end if
    end if
    if m.fullKind <> "vod" or m.playItem = invalid or m.seenSent then return
    if f(m.playItem, "kind", "") <> "ep" then return
    vpos = m.video.position
    dur = m.video.duration
    if vpos > 60 or (dur > 0 and vpos / dur > 0.8) then markSeen()
end sub

sub markSeen()
    it = m.playItem
    if it = invalid or m.seenSent or f(it, "kind", "") <> "ep" then return
    m.seenSent = true
    sendCmd({ c: "seen", sname: f(it, "sname", ""), se: f(it, "se", 0), ep: f(it, "ep", 0) })
    it.badge = "check"
    it.dim = true
end sub

' ---------------- recém assistidos ----------------
sub recAdd(sec as string, it as object)
    if it = invalid then return
    key = f(it, "surl", "")
    if sec = "series" then key = "s:" + lcase(f(it, "sname", it.title))
    if key = "" or key = "s:" then return
    rec = { k: key, n: f(it, "sname", it.title), l: it.hdPosterUrl, t: sec, u: f(it, "surl", ""), alt: f(it, "salt", ""), g: f(it, "grp", ""), sid: f(it, "sid", ""), id: f(it, "seriesId", ""), a: f(it, "adult", false) }
    if sec <> "series" then rec.n = it.title
    sendCmd({ c: "recent", sec: sec, f: rec })
end sub

' canal ao vivo entra nos recentes depois de 10 s em tela cheia (zapeando rápido não conta)
sub recLiveWatch()
    m.recT.control = "stop"
    m.recT.control = "start"
end sub

sub onRecT()
    if m.full and m.fullKind = "live" and m.liveItem <> invalid then recAdd("live", m.liveItem)
end sub

sub goFull()
    m.full = true
    m.fullKind = "live"
    recLiveWatch()
    m.mainGroup.visible = false
    placeVideo()
    m.top.setFocus(true)
    showOsd()
end sub

sub playVod(it as object)
    r = resGet(it)
    if r <> invalid
        m.resItem = it
        m.resT = r.t
        m.resChosen = false
        if m.full and m.fullKind = "vod" then m.video.control = "stop"
        showMsg(it.title, ["Você parou em " + fmtSec(r.t) + " de " + fmtSec(r.d)], ["Continuar de " + fmtSec(r.t), "Começar do início"], "resume")
        return
    end if
    startVod(it, 0)
end sub

sub startVod(it as object, startSec as integer)
    m.resumeAt = startSec
    m.lastResSave = startSec
    m.full = true
    m.fullKind = "vod"
    m.mainGroup.visible = false
    m.osd.visible = false
    placeVideo()
    m.video.visible = true
    m.video.enableUI = true
    playItemNode(it)
    m.video.setFocus(true)
    vk = f(it, "kind", "")
    if vk = "movie" then recAdd("movie", it)
    if vk = "ep" and m.serBack <> invalid and m.serBack.item <> invalid then recAdd("series", m.serBack.item)
end sub

sub closeFull()
    wasVod = (m.fullKind = "vod")
    if wasVod and m.playItem <> invalid and m.video.duration > 0 then resSave(m.playItem, m.video.position, m.video.duration)
    m.full = false
    m.fullKind = ""
    m.osd.visible = false
    m.mainGroup.visible = true
    m.video.enableUI = false
    if wasVod
        stopVideo()
    else
        placeVideo()
    end if
    setZone(m.zone)
    updateSide()
end sub

function nextEpisode() as boolean
    if m.ser = invalid then return false
    m.resumeAt = 0
    season = m.itemList.content
    i = m.itemList.itemFocused + 1
    if season <> invalid and i < season.getChildCount()
        m.itemList.jumpToItem = i
        playVod(season.getChild(i))
        return true
    end if
    sIdx = m.catList.itemFocused + 1
    if sIdx < m.ser.root.getChildCount()
        m.catList.jumpToItem = sIdx
        showSeason(sIdx)
        nxt = m.ser.root.getChild(sIdx).getChild(0)
        if nxt <> invalid
            playVod(nxt)
            return true
        end if
    end if
    return false
end function

sub showOsd()
    m.osd.visible = true
    t = m.top.findNode("osdTimer")
    t.control = "stop"
    t.control = "start"
end sub

sub hideOsd()
    m.osd.visible = false
end sub

sub zap(d as integer)
    c = m.itemList.content
    if c = invalid or f(c, "placeholder", false) or m.liveItem = invalid then return
    n = c.getChildCount()
    cur = 0
    for i = 0 to n - 1
        if f(c.getChild(i), "surl", "") = f(m.liveItem, "surl", "")
            cur = i
            exit for
        end if
    end for
    for k = 1 to n
        cur = (cur + d + n) mod n
        it = c.getChild(cur)
        if not f(it, "locked", false) and f(it, "kind", "") = "live"
            m.itemList.jumpToItem = cur
            playPreview(it)
            return
        end if
    end for
end sub

' ---------------- séries ----------------
sub openSeries(it as object)
    m.ridS = m.ridS + 1
    m.serBack = { c: m.pos[m.sec].c, i: m.pos[m.sec].i, item: it }
    toast("Carregando episódios...")
    sendCmd({ c: "series", rid: m.ridS, sidx: f(it, "sidx", -1), sname: f(it, "sname", it.title), seriesId: f(it, "seriesId", "") })
end sub

sub onSeries()
    root = m.task.outSeries
    if root = invalid or f(root, "rid", -1) <> m.ridS then return
    hideToast()
    if not f(root, "ok", false)
        toast("Esta série não tem episódios disponíveis")
        return
    end if
    m.ser = { root: root, i: 0, poster: f(root, "poster", ""), back: m.serBack }
    m.zone = "items"
    m.catList.content = root
    m.top.findNode("catTitle").text = ucase(f(root, "sname", ""))
    s0 = f(root, "startSeason", 0)
    m.catList.jumpToItem = s0
    showSeason(s0)
    m.itemList.jumpToItem = f(root, "startEp", 0)
    setZone("items")
    updateSide()
end sub

sub showSeason(idx as integer)
    if m.ser = invalid then return
    season = m.ser.root.getChild(idx)
    if season = invalid then return
    m.itemList.content = season
    m.top.findNode("itemTitle").text = ucase(f(m.ser.root, "sname", "") + " · " + season.title)
    updateCount()
    updateSide()
end sub

sub exitSeries()
    b = m.ser.back
    m.ser = invalid
    m.zone = "items"
    m.catList.content = m.catsContent
    m.top.findNode("catTitle").text = m.secTitles[m.sec]
    m.catList.jumpToItem = b.c
    m.pos[m.sec].c = b.c
    m.pos[m.sec].i = b.i
    requestItems()
    setZone("items")
end sub

' ---------------- diálogos ----------------
sub showMsg(title as string, lines as object, buttons as object, kind as string)
    d = CreateObject("roSGNode", "StandardMessageDialog")
    d.title = title
    d.message = lines
    d.buttons = buttons
    d.observeField("buttonSelected", "onMsgButton")
    d.observeField("wasClosed", "onDlgClosed")
    m.dlgKind = kind
    m.scene.dialog = d
end sub

sub onDlgClosed()
    if m.dlgKind = "resume" and m.resChosen <> true
        m.resChosen = true
        if m.full and m.fullKind = "vod" then closeFull()
    end if
    if m.settings.visible
        m.settingsList.setFocus(true)
    else if m.full
        if m.fullKind = "vod" then m.video.setFocus(true) else m.top.setFocus(true)
    else if m.loading.visible
        m.top.setFocus(true)
    else
        setZone(m.zone)
    end if
end sub

sub closeDlg()
    if m.scene.dialog <> invalid then m.scene.dialog.close = true
end sub

sub onMsgButton()
    b = m.scene.dialog.buttonSelected
    kind = m.dlgKind
    closeDlg()
    if kind = "loadErr"
        if b = 0 then startLoad(true) else openSettings()
    else if kind = "resume"
        m.resChosen = true
        if m.resItem <> invalid
            if b = 0
                startVod(m.resItem, m.resT)
                toast("Continuando de " + fmtSec(m.resT))
            else
                resDel(resKey(m.resItem))
                startVod(m.resItem, 0)
            end if
        end if
    else if kind = "upd"
        if b = 0 then applyUpdate()
    else if kind = "exitLoad"
        if b = 0 then m.top.exitApp = true
        if b = 1 then openSettings()
    else if kind = "exit"
        if b = 0 then m.top.exitApp = true
    else if kind = "options"
        doOption(m.optActs[b])
    else if kind = "listMenu"
        if b = 0
            m.activeId = m.lists[m.edIdx].id
            saveLists()
            closeSettings()
            startLoad(false)
        else if b = 1
            startEditList(m.edIdx)
        else if b = 2
            showMsg("Excluir lista", ["Excluir a lista " + m.lists[m.edIdx].name + "?"], ["Excluir", "Cancelar"], "delList")
        end if
    else if kind = "delList"
        if b = 0
            wasActive = (m.lists[m.edIdx].id = m.activeId)
            m.lists.delete(m.edIdx)
            if wasActive
                m.activeId = ""
                m.loaded = false
                if m.lists.count() > 0 then m.activeId = m.lists[0].id
            end if
            saveLists()
            toast("Lista excluída")
            openSettings()
        end if
    else if kind = "addType"
        if b = 0 then startNewList("m3u")
        if b = 1 then startNewList("xtream")
        if b = 2 and activeList() = invalid then showMsg("NxTv", ["Para usar o app, cadastre uma lista."], ["Cadastrar lista", "Sair"], "noList")
    else if kind = "noList"
        if b = 0 then startAddList() else m.top.exitApp = true
    end if
end sub

' teclado na tela (dá para digitar pelo app Roku no celular)
sub askText(title as string, value as string, kind as string, secure = false as boolean)
    d = CreateObject("roSGNode", "StandardKeyboardDialog")
    d.title = title
    d.text = value
    d.buttons = ["OK", "Cancelar"]
    d.observeField("buttonSelected", "onKbButton")
    d.observeField("wasClosed", "onDlgClosed")
    m.kbKind = kind
    m.scene.dialog = d
end sub

sub onKbButton()
    d = m.scene.dialog
    b = d.buttonSelected
    txt = d.text
    kind = m.kbKind
    closeDlg()
    if b <> 0
        if kind = "ed" and m.ed <> invalid and activeList() = invalid then showMsg("NxTv", ["Para usar o app, cadastre uma lista."], ["Cadastrar lista", "Sair"], "noList")
        return
    end if
    if kind = "search"
        txt = txt.trim()
        if txt.len() < 2
            toast("Digite ao menos 2 letras")
            return
        end if
        runSearch(txt)
    else if kind = "ed"
        edStore(txt.trim())
    end if
end sub

sub askPin(after as string)
    m.pinAfter = after
    d = CreateObject("roSGNode", "StandardPinPadDialog")
    d.title = "Conteúdo adulto"
    d.message = ["Digite a senha de 4 números"]
    d.buttons = ["OK", "Cancelar"]
    d.observeField("buttonSelected", "onPinButton")
    d.observeField("wasClosed", "onDlgClosed")
    m.pinStep = "unlock"
    m.scene.dialog = d
end sub

sub onPinButton()
    d = m.scene.dialog
    b = d.buttonSelected
    pin = d.pin
    closeDlg()
    if b <> 0 then return
    if m.pinStep = "unlock"
        if pin = m.pin
            m.unlocked = true
            toast("Conteúdo adulto liberado até fechar o app")
            ' recarrega as listas sem a máscara
            keepZone = "items"
            if m.pinAfter = "cats" then keepZone = "items"
            requestGroups(m.sec)
            setZone(keepZone)
        else
            toast("Senha incorreta")
        end if
    else if m.pinStep = "old"
        if pin = m.pin then askNewPin("new") else toast("Senha atual incorreta")
    else if m.pinStep = "new"
        if pin.len() <> 4
            toast("A senha precisa ter 4 números")
            return
        end if
        m.newPin = pin
        askNewPin("confirm")
    else if m.pinStep = "confirm"
        if pin = m.newPin
            m.pin = pin
            regWrite("pin", pin)
            toast("Senha alterada")
            openSettings()
        else
            toast("As senhas não conferem")
        end if
    end if
end sub

sub askNewPin(stepName as string)
    d = CreateObject("roSGNode", "StandardPinPadDialog")
    d.title = "Alterar senha"
    msg = "Digite a senha ATUAL"
    if stepName = "new" then msg = "Digite a NOVA senha (4 números)"
    if stepName = "confirm" then msg = "Digite a NOVA senha de novo"
    d.message = [msg]
    d.buttons = ["OK", "Cancelar"]
    d.observeField("buttonSelected", "onPinButton")
    d.observeField("wasClosed", "onDlgClosed")
    m.pinStep = stepName
    m.scene.dialog = d
end sub

sub openSearch()
    askText("Pesquisar canal, filme ou série", m.query, "search")
end sub

' menu do botão * (opções)
sub openOptions()
    acts = []
    labels = []
    it = curItem()
    if it <> invalid and not f(it, "locked", false)
        k = f(it, "kind", "")
        if k = "live" or k = "movie" or k = "series"
            if f(it, "badge", "") = "star"
                labels.push("Remover dos favoritos")
            else
                labels.push("Adicionar aos favoritos")
            end if
            acts.push("fav")
        end if
    end if
    labels.append(["Pesquisar", "Configurações", "Atualizar lista", "Cancelar"])
    acts.append(["search", "settings", "reload", "cancel"])
    m.optActs = acts
    title = "Opções"
    if it <> invalid and not f(it, "locked", false) then title = it.title
    showMsg(title, [""], labels, "options")
end sub

sub doOption(a as string)
    if a = "fav" then toggleFav()
    if a = "search" then openSearch()
    if a = "settings" then openSettings()
    if a = "reload" then startLoad(true)
end sub

sub toggleFav()
    it = curItem()
    if it = invalid then return
    k = f(it, "kind", "")
    key = f(it, "surl", "")
    if k = "series" then key = "s:" + lcase(f(it, "sname", it.title))
    fav = { k: key, n: it.title, l: it.hdPosterUrl, t: k, u: f(it, "surl", ""), alt: f(it, "salt", ""), g: f(it, "grp", ""), sid: f(it, "sid", ""), id: f(it, "seriesId", "") }
    sendCmd({ c: "fav", f: fav })
    if f(it, "badge", "") = "star"
        it.badge = ""
        toast("Removido dos favoritos")
        if m.sec = "fav" then requestItems()
    else
        it.badge = "star"
        toast("Adicionado aos favoritos")
    end if
end sub

' ---------------- configurações ----------------
sub openSettings()
    if m.full then closeFull()
    stopVideo()
    root = CreateObject("roSGNode", "ContentNode")
    i = 0
    for each L in m.lists
        n = root.createChild("ContentNode")
        n.title = L.name
        t = "M3U"
        if L.type = "xtream" then t = "Xtream"
        if L.id = m.activeId then t = "EM USO · " + t
        n.shortDescriptionLine1 = t
        n.addFields({ act: "list", idx: i, big: true })
        i = i + 1
    end for
    addSet(root, "+ Adicionar nova lista", "", "add")
    if m.lists.count() > 0 then addSet(root, "Atualizar lista em uso (baixar de novo)", "", "reload")
    pinTxt = "****"
    if m.pin = "0000" then pinTxt = "padrão 0000"
    addSet(root, "Senha do conteúdo adulto · alterar", pinTxt, "pin")
    ordTxt = "IGUAL À LISTA"
    if m.order = "az" then ordTxt = "ALFABÉTICA"
    addSet(root, "Ordem de canais, filmes e séries", ordTxt, "order")
    atTxt = "NORMAL"
    if m.anti = "forte" then atTxt = "FORTE"
    if m.anti = "off" then atTxt = "DESLIGADO"
    addSet(root, "Antitravamento", atTxt, "anti")
    if m.unlocked then addSet(root, "Bloquear conteúdo adulto agora", "", "lock")
    addSet(root, "Atualizar app (procurar versão nova)", "VERSÃO " + appVer(), "appupd")
    if m.top.fromLib then addSet(root, "Voltar para a versão original do app", m.top.factoryVer, "appreset")
    if m.loaded then addSet(root, "Voltar para a TV", "", "back")
    m.settingsList.content = root
    m.loading.visible = false
    m.settings.visible = true
    m.settingsList.setFocus(true)
end sub

sub addSet(root as object, title as string, right as string, act as string)
    n = root.createChild("ContentNode")
    n.title = title
    n.shortDescriptionLine1 = right
    n.addFields({ act: act, idx: -1, big: true })
end sub

sub closeSettings()
    m.settings.visible = false
    if m.loaded
        setZone(m.zone)
        updateSide()
    else if activeList() <> invalid
        startLoad(false)
    else
        showLoading("Bem-vindo ao NxTv", "Vamos cadastrar a sua lista")
        startAddList()
    end if
end sub

sub onSettingSelect()
    n = m.settingsList.content.getChild(m.settingsList.itemSelected)
    if n = invalid then return
    a = f(n, "act", "")
    if a = "list"
        m.edIdx = f(n, "idx", 0)
        showMsg(m.lists[m.edIdx].name, ["O que deseja fazer com esta lista?"], ["Usar esta lista", "Editar", "Excluir", "Cancelar"], "listMenu")
    else if a = "add"
        startAddList()
    else if a = "reload"
        closeSettings()
        startLoad(true)
    else if a = "pin"
        askNewPin("old")
    else if a = "order"
        if m.order = "az" then m.order = "list" else m.order = "az"
        regWrite("order", m.order)
        closeSettings()
        startLoad(false)
    else if a = "anti"
        if m.anti = "normal"
            m.anti = "forte"
            toast("Antitravamento FORTE: reconecta mais rápido e tenta mais vezes")
        else if m.anti = "forte"
            m.anti = "off"
            toast("Antitravamento desligado")
        else
            m.anti = "normal"
            toast("Antitravamento NORMAL")
        end if
        regWrite("anti", m.anti)
        keep = m.settingsList.itemSelected
        openSettings()
        m.settingsList.jumpToItem = keep
    else if a = "lock"
        m.unlocked = false
        toast("Conteúdo adulto bloqueado")
        openSettings()
    else if a = "appupd"
        checkUpdate()
    else if a = "appreset"
        resetUpdate()
    else if a = "back"
        closeSettings()
    end if
end sub

' cadastro / edição de lista (passo a passo com o teclado)
sub startAddList()
    showMsg("Nova lista", ["Qual é o tipo da sua lista?"], ["Link M3U", "Xtream Codes (servidor, usuário e senha)", "Cancelar"], "addType")
end sub

sub startNewList(t as string)
    m.ed = { idx: -1, L: { type: t, name: "", url: "", server: "", user: "", pass: "" }, step: 0, fromStart: not m.loaded }
    edAsk()
end sub

sub startEditList(idx as integer)
    L = m.lists[idx]
    m.ed = { idx: idx, L: { type: L.type, name: L.name, url: strOr(L.url), server: strOr(L.server), user: strOr(L.user), pass: strOr(L.pass) }, step: 0, fromStart: false }
    edAsk()
end sub

function strOr(v as dynamic) as string
    if v = invalid then return ""
    return v
end function

function edSteps() as object
    if m.ed.L.type = "xtream" then return ["name", "server", "user", "pass"]
    return ["name", "url"]
end function

sub edAsk()
    st = edSteps()[m.ed.step]
    L = m.ed.L
    if st = "name" then askText("Nome da lista (ex.: Minha lista)", L.name, "ed")
    if st = "url" then askText("Link da lista (http://...)", L.url, "ed")
    if st = "server" then askText("Servidor (ex.: http://servidor.com:8080)", L.server, "ed")
    if st = "user" then askText("Usuário", L.user, "ed")
    if st = "pass" then askText("Senha", L.pass, "ed")
end sub

sub edStore(v as string)
    steps = edSteps()
    st = steps[m.ed.step]
    L = m.ed.L
    if st = "name"
        if v = "" then v = "Minha lista"
        L.name = v
    else if st = "url"
        if lcase(v.left(4)) <> "http"
            toast("O link precisa começar com http:// ou https://")
            edAsk()
            return
        end if
        L.url = v
    else if st = "server"
        if v = ""
            toast("Digite o servidor")
            edAsk()
            return
        end if
        L.server = v
    else if st = "user"
        L.user = v
    else if st = "pass"
        L.pass = v
    end if
    m.ed.step = m.ed.step + 1
    if m.ed.step < steps.count()
        edAsk()
        return
    end if
    ' salvar
    if m.ed.idx >= 0
        L.id = m.lists[m.ed.idx].id
        m.lists[m.ed.idx] = L
    else
        L.id = "l" + CreateObject("roDateTime").asSeconds().toStr()
        m.lists.push(L)
    end if
    m.activeId = L.id
    saveLists()
    m.settings.visible = false
    startLoad(true)
end sub

' ---------------- controle remoto ----------------
function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.loading.visible
        if key = "back"
            showMsg("Sair", ["Deseja sair do NxTv?"], ["Sair", "Configurações", "Cancelar"], "exitLoad")
            return true
        end if
        if key = "OK" and not m.spinner.visible
            showMsg("Erro ao carregar", ["Não foi possível carregar a lista."], ["Tentar novamente", "Configurações"], "loadErr")
            return true
        end if
        return true
    end if
    if m.detIsOpen then return detKey(key)
    if m.settings.visible
        if key = "back"
            closeSettings()
            return true
        end if
        return false
    end if
    if m.full
        if m.fullKind = "live"
            if key = "up" then zap(-1)
            if key = "down" then zap(1)
            if key = "OK" or key = "left" or key = "right" then showOsd()
            if key = "back" then closeFull()
            if key = "options" then openOptions()
            return true
        end if
        if key = "back"
            closeFull()
            return true
        end if
        if key = "up" and m.ser <> invalid
            if nextEpisode() then return true
        end if
        return false
    end if
    if key = "options"
        openOptions()
        return true
    end if
    if key = "replay"
        openSearch()
        return true
    end if
    if key = "back"
        if m.zone = "items"
            setZone("cats")
        else if m.zone = "cats"
            if m.ser <> invalid then exitSeries() else setZone("nav")
        else
            showMsg("Sair", ["Deseja sair do NxTv?"], ["Sair", "Cancelar"], "exit")
        end if
        return true
    end if
    if key = "left"
        if m.zone = "items"
            setZone("cats")
        else if m.zone = "cats"
            if m.ser <> invalid then exitSeries() else setZone("nav")
        end if
        return true
    end if
    if key = "right"
        if m.zone = "nav"
            if m.sections[m.navList.itemFocused] = "settings"
                openSettings()
            else if m.sec = "search" and m.query = ""
                openSearch()
            else
                setZone("cats")
            end if
        else if m.zone = "cats"
            onCatSelectByKey()
        else if m.zone = "items"
            it = curItem()
            if it <> invalid
                kd = f(it, "kind", "")
                if m.ser <> invalid and kd = "" then kd = "ep"
                if kd = "movie" or kd = "series" or kd = "ep"
                    if f(it, "locked", false) then askPin("item") else detOpen(it)
                end if
            end if
        end if
        return true
    end if
    return false
end function

' ---------------- sinopse em tela cheia ----------------
sub detOpen(it as object)
    m.detItem = it
    m.detSel = 0
    m.detIsOpen = true
    detFill()
    m.top.findNode("detPanel").visible = true
    m.top.setFocus(true)
end sub

sub detFill()
    it = m.detItem
    if it = invalid then return
    kd = f(it, "kind", "")
    if m.ser <> invalid and kd <> "movie" and kd <> "series" then kd = "ep"
    name = it.title
    key = ""
    gen = f(it, "grp", "")
    meta = ""
    if kd = "movie" then key = "m:" + f(it, "surl", "")
    if kd = "series"
        key = "s:" + lcase(f(it, "sname", it.title))
        meta = it.shortDescriptionLine1
    end if
    if kd = "ep"
        key = "s:" + lcase(f(it, "sname", ""))
        name = f(it, "sname", "") + " · " + f(it, "epLabel", "") + " — " + it.title
        if f(it, "se", 0) > 0 then name = f(it, "sname", "") + " · T" + f(it, "se", 0).toStr() + " · " + f(it, "epLabel", "") + " — " + it.title
        gen = ""
    end if
    plot = ""
    inf = invalid
    if key <> "" then inf = m.vinfo[key]
    if inf <> invalid
        if inf.genre <> "" then gen = inf.genre
        if inf.line <> ""
            if meta <> "" then meta = inf.line + " · " + meta else meta = inf.line
        end if
        plot = inf.plot
        if plot = "" then plot = "Sem sinopse"
    else
        plot = "Carregando sinopse..."
    end if
    poster = it.hdPosterUrl
    if poster = "" and m.ser <> invalid then poster = m.ser.poster
    m.top.findNode("detName").text = name
    m.top.findNode("detGenre").text = gen
    m.top.findNode("detMeta").text = meta
    m.top.findNode("detPlot").text = plot
    m.top.findNode("detPoster").uri = poster
    b0 = "Assistir"
    if kd = "series" then b0 = "Ver episódios"
    if kd <> "series"
        r = resGet(it)
        if r <> invalid then b0 = "Continuar"
    end if
    m.top.findNode("detB0Lbl").text = b0
    detSelShow()
end sub

sub detSelShow()
    cOn = "0xFF7A00FF"
    cOff = "0x1A3166FF"
    if m.detSel = 0
        m.top.findNode("detB0").color = cOn
        m.top.findNode("detB1").color = cOff
    else
        m.top.findNode("detB0").color = cOff
        m.top.findNode("detB1").color = cOn
    end if
end sub

sub detClose()
    m.detIsOpen = false
    m.top.findNode("detPanel").visible = false
    setZone("items")
end sub

function detKey(key as string) as boolean
    if key = "left"
        m.detSel = 0
        detSelShow()
    else if key = "right"
        m.detSel = 1
        detSelShow()
    else if key = "back"
        detClose()
    else if key = "OK" or key = "play"
        it = m.detItem
        if m.detSel = 1 and key = "OK"
            detClose()
            return true
        end if
        detClose()
        kd = f(it, "kind", "")
        if kd = "series"
            openSeries(it)
        else
            playVod(it)
        end if
    end if
    return true
end function

sub onCatSelectByKey()
    if m.ser <> invalid
        setZone("items")
        return
    end if
    if m.catsContent = invalid or f(m.catList.content, "placeholder", false) then return
    g = m.catsContent.getChild(m.catList.itemFocused)
    if g <> invalid and f(g, "adult", false) and not m.unlocked
        askPin("cats")
        return
    end if
    setZone("items")
end sub

' ---------------- continuar de onde parou ----------------
function tStr(v as dynamic) as string
    if v = invalid then return ""
    if type(v) = "roString" or type(v) = "String" then return v
    return v.toStr()
end function

function resKey(it as object) as string
    if f(it, "kind", "") = "ep" then return "w:" + f(it, "sname", "") + "|" + tStr(f(it, "se", 0)) + "|" + tStr(f(it, "ep", 0))
    return "m:" + lcase(it.title)
end function

function resAll() as object
    if m.resMap = invalid
        m.resMap = ParseJSON(regRead("resume", "{}"))
        if m.resMap = invalid then m.resMap = {}
    end if
    return m.resMap
end function

function resGet(it as object) as dynamic
    r = resAll()[resKey(it)]
    if r = invalid or r.t = invalid or r.t < 30 then return invalid
    return r
end function

sub resDel(k as string)
    mp = resAll()
    if mp.doesExist(k)
        mp.delete(k)
        regWrite("resume", FormatJSON(mp))
    end if
end sub

sub resSave(it as object, posSec as dynamic, durSec as dynamic)
    if it = invalid or posSec = invalid then return
    t = int(posSec)
    d = 0
    if durSec <> invalid then d = int(durSec)
    k = resKey(it)
    if t < 30 or (d > 0 and t > d * 0.95)
        resDel(k)
        return
    end if
    mp = resAll()
    mp[k] = { t: t, d: d, at: CreateObject("roDateTime").asSeconds() }
    ' guarda só os 60 mais recentes (o registro da Roku é pequeno)
    if mp.count() > 60
        oldK = ""
        oldT = 0
        for each kk in mp
            if oldK = "" or mp[kk].at < oldT
                oldK = kk
                oldT = mp[kk].at
            end if
        end for
        if oldK <> "" then mp.delete(oldK)
    end if
    regWrite("resume", FormatJSON(mp))
end sub

function fmtSec(s as dynamic) as string
    if s = invalid then return "0:00"
    n = int(s)
    h = int(n / 3600)
    mi = int((n mod 3600) / 60)
    se = n mod 60
    ss = se.toStr()
    if se < 10 then ss = "0" + ss
    if h > 0
        ms = mi.toStr()
        if mi < 10 then ms = "0" + ms
        return h.toStr() + ":" + ms + ":" + ss
    end if
    return mi.toStr() + ":" + ss
end function
