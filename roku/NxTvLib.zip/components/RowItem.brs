' Linha usada nas listas (menu, categorias, canais, filmes, séries, episódios)
sub init()
    m.bg = m.top.findNode("bg")
    m.bar = m.top.findNode("bar")
    m.num = m.top.findNode("num")
    m.logo = m.top.findNode("logo")
    m.title = m.top.findNode("title")
    m.scroll = m.top.findNode("scroll")
    m.right = m.top.findNode("right")
    m.badge = m.top.findNode("badge")
    m.dim = false
    m.big = false
    m.hasLogo = false
    m.compact = false
end sub

function fieldOr(c as object, name as string, def as dynamic) as dynamic
    if c.hasField(name)
        v = c.getField(name)
        if v <> invalid then return v
    end if
    return def
end function

sub onContent()
    c = m.top.itemContent
    if c = invalid then return
    m.title.text = c.title
    m.scroll.text = c.title
    m.num.text = fieldOr(c, "num", "")
    m.right.text = c.shortDescriptionLine1
    logo = c.hdPosterUrl
    m.hasLogo = fieldOr(c, "showLogo", false)
    if m.hasLogo then m.logo.uri = logo else m.logo.uri = ""
    badge = fieldOr(c, "badge", "")
    if badge <> "" then m.badge.uri = "pkg:/images/" + badge + ".png" else m.badge.uri = ""
    m.dim = fieldOr(c, "dim", false)
    m.big = fieldOr(c, "big", false)
    m.compact = fieldOr(c, "compact", false)
    if m.compact
        m.title.font.size = 27
    else if m.big
        m.title.font.size = 31
    else
        m.title.font.size = 29
    end if
    m.scroll.font.size = m.title.font.size
    layout()
    onFocus()
end sub

sub layout()
    w = m.top.width
    h = m.top.height
    if w = 0 then w = 600
    if h = 0 then h = 66
    m.bg.width = w
    m.bg.height = h
    m.bar.height = h
    x = 24
    if m.compact then x = 16
    if m.num.text <> ""
        m.num.translation = [x, 0]
        m.num.width = 72
        m.num.height = h
        x = x + 80
    end if
    if m.hasLogo = true
        m.logo.visible = true
        if m.compact
            m.logo.width = 50
            m.logo.translation = [x, (h - 50) / 2]
            x = x + 64
        else
            m.logo.width = 78
            m.logo.translation = [x, (h - 50) / 2]
            x = x + 92
        end if
    else
        m.logo.visible = false
    end if
    badgeW = 0
    if m.badge.uri <> "" then badgeW = 44
    rightW = 0
    if m.right.text <> ""
        rightW = len(m.right.text) * 13 + 12
        if rightW > 260 then rightW = 260
    end if
    m.title.translation = [x, 0]
    m.title.width = w - x - badgeW - rightW - 14
    m.title.height = h
    m.scroll.translation = [x, 0]
    m.scroll.maxWidth = m.title.width
    m.scroll.height = h
    m.right.translation = [w - badgeW - rightW - 12, 0]
    m.right.width = rightW
    m.right.height = h
    m.badge.translation = [w - badgeW, (h - 30) / 2]
end sub

sub onFocus()
    f = m.top.focusPercent
    if m.top.listHasFocus
        m.bg.color = "0xFF7A00FF"
        m.bg.opacity = f
        m.bar.opacity = 0
    else
        m.bg.color = "0x1A3166FF"
        m.bg.opacity = f
        m.bar.opacity = f
    end if
    sc = (m.top.listHasFocus and f > 0.9)
    m.scroll.visible = sc
    m.title.visible = not sc
    if m.top.listHasFocus and f > 0.5
        m.title.color = "0xFFFFFFFF"
        m.num.color = "0xFFFFFFFF"
        m.right.color = "0xFFFFFFFF"
    else
        if m.dim then m.title.color = "0x7F93BDFF" else m.title.color = "0xD6E0F5FF"
        m.num.color = "0x6F86B5FF"
        m.right.color = "0x6F86B5FF"
    end if
end sub
