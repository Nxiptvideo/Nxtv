' NxTv - tarefa de dados: baixa a lista, organiza e responde às telas
sub init()
    m.top.functionName = "runLoop"
end sub

sub runLoop()
    m.port = CreateObject("roMessagePort")
    m.top.observeField("cmd", m.port)
    m.lastSeq = -1
    try
        setupTask()
    catch e
        print "NxTv setupTask erro: "; e.message
    end try
    ' pedido feito antes da tarefa começar a ouvir (ex.: abrir a lista logo ao iniciar)
    pend = m.top.cmd
    if pend <> invalid and pend.c <> invalid then safeHandle(pend)
    while true
        msg = wait(0, m.port)
        if type(msg) = "roSGNodeEvent" and msg.getField() = "cmd"
            c = msg.getData()
            if c <> invalid and c.c <> invalid then safeHandle(c)
        end if
    end while
end sub

sub safeHandle(c as object)
    if c.seq <> invalid
        if c.seq = m.lastSeq then return
        m.lastSeq = c.seq
    end if
    try
        handle(c)
    catch e
        print "NxTv erro em "; c.c; ": "; e.message
        if c.c = "load" then m.top.outLoad = { ok: false, msg: "Erro ao organizar a lista (" + e.message + ")" }
    end try
end sub

sub setupTask()
    m.reg = CreateObject("roRegistrySection", "NxTv")
    m.adultG = CreateObject("roRegex", "(^|[^a-z0-9])(adult[a-z]*|xxx|\+ ?18|18 ?\+|porn[a-z]*|erotic[a-z]*|sex|sexy|hot|playboy|onlyfans)([^a-z0-9]|$)", "i")
    m.adultN = CreateObject("roRegex", "(^|[^a-z0-9])(adult[a-z]*|xxx|\+ ?18|18 ?\+|porn[a-z]*|erotic[a-z]*|sexy|playboy|brasileirinhas|hustler|onlyfans)([^a-z0-9]|$)", "i")
    m.ep1 = CreateObject("roRegex", "^(.*?)[\s._\-|:]*[ST](\d{1,2})[\s._\-]*EP?(\d{1,4})", "i")
    m.epStrip = CreateObject("roRegex", "^.*?[ST]\d{1,2}[\s._\-]*EP?\d{1,4}[\s\-:|.]*", "i")
    m.attr = CreateObject("roRegex", "([\w-]+)=" + chr(34) + "([^" + chr(34) + "]*)" + chr(34), "")
    m.vodExt = CreateObject("roRegex", "\.(mp4|mkv|avi|mov|m4v|flv|mpg)(\?|$)", "i")
    resetData()
end sub

sub resetData()
    m.ch = []
    m.series = []
    m.sKey = {}
    m.groups = { live: [], movie: [], series: [] }
    m.api = invalid
    m.search = invalid
    m.order = "list"
end sub

sub handle(c as object)
    print "NxTv tarefa: comando "; c.c
    if c.c = "load" then doLoad(c)
    if c.c = "groups" then doGroups(c)
    if c.c = "items" then doItems(c)
    if c.c = "series" then doSeries(c)
    if c.c = "search" then doSearch(c)
    if c.c = "epg" then doEpg(c)
    if c.c = "upd" then doUpd()
    if c.c = "fav" then doFav(c)
    if c.c = "seen" then doSeen(c)
end sub

sub setStatus(s as string)
    m.top.status = s
end sub

' ---------------- rede ----------------
function httpGet(url as string, timeoutMs = 60000 as integer) as dynamic
    x = CreateObject("roUrlTransfer")
    p = CreateObject("roMessagePort")
    x.setMessagePort(p)
    x.setUrl(url)
    x.setCertificatesFile("common:/certs/ca-bundle.crt")
    x.initClientCertificates()
    x.enableEncodings(true)
    x.retainBodyOnError(false)
    if not x.asyncGetToString() then return invalid
    print "NxTv tarefa: baixando..."
    ev = wait(timeoutMs, p)
    if type(ev) = "roUrlEvent" then print "NxTv tarefa: resposta "; ev.getResponseCode() else print "NxTv tarefa: tempo esgotado"
    if type(ev) = "roUrlEvent"
        code = ev.getResponseCode()
        if code >= 200 and code < 400 then return ev.getString()
        return invalid
    end if
    x.asyncCancel()
    return invalid
end function

function enc(s as string) as string
    x = CreateObject("roUrlTransfer")
    return x.escape(s)
end function

function apiUrl(action as string, extra = "" as string) as string
    a = m.api
    return a.base + "/player_api.php?username=" + enc(a.u) + "&password=" + enc(a.p) + "&action=" + action + extra
end function

function credsOf(L as object) as dynamic
    if L.type = "xtream"
        s = L.server.trim()
        while s.right(1) = "/"
            s = s.left(s.len() - 1)
        end while
        if lcase(s.left(4)) <> "http" then s = "http://" + s
        return { base: s, u: L.user, p: L.pass }
    end if
    url = L.url
    if url = invalid then return invalid
    r = CreateObject("roRegex", "^(https?://[^/?#]+)/get\.php\?(.*)$", "i")
    mm = r.match(url)
    if mm.count() < 3 then return invalid
    ru = CreateObject("roRegex", "(^|&)username=([^&]*)", "i").match(mm[2])
    rp = CreateObject("roRegex", "(^|&)password=([^&]*)", "i").match(mm[2])
    if ru.count() < 3 or rp.count() < 3 then return invalid
    x = CreateObject("roUrlTransfer")
    return { base: mm[1], u: x.unescape(ru[2]), p: x.unescape(rp[2]) }
end function

function isAdultTxt(s as string, isGroup as boolean) as boolean
    if isGroup then return m.adultG.isMatch(lcase(s))
    return m.adultN.isMatch(lcase(s))
end function

' ---------------- carregar lista ----------------
sub doLoad(c as object)
    resetData()
    L = c.list
    m.order = c.order
    if m.order = invalid then m.order = "list"
    m.listId = L.id
    setStatus("Conectando ao servidor...")
    cr = credsOf(L)
    ok = false
    if cr <> invalid
        m.api = cr
        ok = loadApi(L, c.force = true)
        if not ok then m.api = invalid
    end if
    if not ok then ok = loadM3U(L)
    if ok
        m.top.outLoad = { ok: true, api: m.api <> invalid, live: m.groups.live.count(), movie: m.groups.movie.count(), series: m.groups.series.count() }
    else
        m.top.outLoad = { ok: false, msg: "Não foi possível carregar a lista. Verifique a internet e os dados da lista." }
    end if
end sub

function cachedOrGet(key as string, action as string, force as boolean) as dynamic
    path = "cachefs:/nx_" + m.listId + "_" + key + ".json"
    fs = CreateObject("roFileSystem")
    stamp = m.reg.read("t_" + m.listId + "_" + key)
    now = CreateObject("roDateTime").asSeconds()
    if not force and stamp <> "" and fs.exists(path) and now - stamp.toInt() < 43200
        setStatus("Abrindo lista salva...")
        txt = ReadAsciiFile(path)
        if txt <> "" then return txt
    end if
    txt = httpGet(apiUrl(action), 90000)
    if txt <> invalid and txt <> ""
        if WriteAsciiFile(path, txt)
            m.reg.write("t_" + m.listId + "_" + key, now.toStr())
            m.reg.flush()
        end if
    end if
    return txt
end function

function loadApi(L as object, force as boolean) as boolean
    setStatus("Carregando categorias...")
    lcTxt = cachedOrGet("lc", "get_live_categories", force)
    if lcTxt = invalid then return false
    lc = ParseJSON(lcTxt)
    if type(lc) <> "roArray" then return false
    setStatus("Carregando canais ao vivo...")
    lsTxt = cachedOrGet("ls", "get_live_streams", force)
    if lsTxt = invalid then return false
    ls = ParseJSON(lsTxt)
    lsTxt = invalid
    if type(ls) <> "roArray" or ls.count() = 0 then return false
    setStatus("Carregando filmes e séries...")
    vc = ParseJSON(validStr(cachedOrGet("vc", "get_vod_categories", force)))
    sc = ParseJSON(validStr(cachedOrGet("sc", "get_series_categories", force)))
    setStatus("Organizando canais...")
    base = m.api.base + "/live/" + enc(m.api.u) + "/" + enc(m.api.p) + "/"
    ' categorias ao vivo na ordem do servidor
    catIdx = {}
    for each cat in lc
        cid = "c" + anyStr(cat.category_id)
        if catIdx[cid] = invalid
            nm = anyStr(cat.category_name)
            if nm = "" then nm = "Sem categoria"
            catIdx[cid] = m.groups.live.count()
            m.groups.live.push({ name: nm, items: [], adult: isAdultTxt(nm, true), lazy: invalid })
        end if
    end for
    others = invalid
    for each s in ls
        nm = anyStr(s.name)
        cid = "c" + anyStr(s.category_id)
        gi = catIdx[cid]
        if gi = invalid
            if others = invalid
                others = m.groups.live.count()
                m.groups.live.push({ name: "Outros", items: [], adult: false, lazy: invalid })
            end if
            gi = others
        end if
        g = m.groups.live[gi]
        id = anyStr(s.stream_id)
        ch = { n: nm, l: anyStr(s.stream_icon), g: g.name, u: base + id + ".m3u8", alt: base + id + ".ts", t: "live", a: g.adult or isAdultTxt(nm, false), sid: id, o: anyInt(s.num) }
        g.items.push(m.ch.count())
        m.ch.push(ch)
    end for
    ls = invalid
    finishLive()
    if type(vc) = "roArray" then m.groups.movie = lazyGroups(vc, "get_vod_streams")
    if type(sc) = "roArray" then m.groups.series = lazyGroups(sc, "get_series")
    return true
end function

function validStr(s as dynamic) as string
    if s = invalid then return "[]"
    return s
end function

function anyStr(v as dynamic) as string
    if v = invalid then return ""
    t = type(v)
    if t = "roString" or t = "String" then return v
    if t = "roInteger" or t = "Integer" or t = "LongInteger" then return v.toStr()
    if t = "roFloat" or t = "Float" or t = "Double" then return Int(v).toStr()
    return ""
end function

function anyInt(v as dynamic) as integer
    s = anyStr(v)
    if s = "" then return 0
    return s.toInt()
end function

function lazyGroups(arr as object, act as string) as object
    out = []
    for each cat in arr
        nm = anyStr(cat.category_name)
        if nm = "" then nm = "Sem categoria"
        out.push({ name: nm, items: invalid, adult: isAdultTxt(nm, true), lazy: { act: act, cat: anyStr(cat.category_id) } })
    end for
    return orderGroups(out)
end function

' ordem: igual à lista (adultos no fim) ou alfabética
function orderGroups(arr as object) as object
    if m.order = "az"
        for each g in arr
            g.k = lcase(g.name)
        end for
        arr.sortBy("k")
    end if
    a = []
    b = []
    for each g in arr
        if g.adult then b.push(g) else a.push(g)
    end for
    a.append(b)
    return a
end function

function orderIdx(idx as object, src as object) as object
    if m.order = "az"
        tmp = []
        for each i in idx
            tmp.push({ i: i, k: lcase(src[i].n) })
        end for
        tmp.sortBy("k")
        idx = []
        for each t in tmp
            idx.push(t.i)
        end for
    end if
    a = []
    b = []
    for each i in idx
        if src[i].a = true then b.push(i) else a.push(i)
    end for
    a.append(b)
    return a
end function

sub finishLive()
    allIdx = []
    for each g in m.groups.live
        g.items = orderIdx(g.items, m.ch)
        for each i in g.items
            allIdx.push(i)
        end for
        if not g.adult and g.items.count() > 0
            allAdult = true
            for each i in g.items
                if not m.ch[i].a then allAdult = false
            end for
            g.adult = allAdult
        end if
    end for
    m.groups.live = orderGroups(m.groups.live)
    ' "Todos os canais" na ordem original da lista (ou numeração do servidor)
    tmp = []
    for each i in allIdx
        o = m.ch[i].o
        if o = invalid or o = 0 then o = i + 1000000
        tmp.push({ i: i, o: o })
    end for
    tmp.sortBy("o")
    allIdx = []
    for each t in tmp
        allIdx.push(t.i)
    end for
    allIdx = orderIdx(allIdx, m.ch)
    n = 1
    for each i in allIdx
        m.ch[i].num = n
        n = n + 1
    end for
    m.groups.live.unshift({ name: "Todos os canais", items: allIdx, adult: false, lazy: invalid })
end sub

' ---------------- lista M3U ----------------
function loadM3U(L as object) as boolean
    url = L.url
    if L.type = "xtream"
        cr = credsOf(L)
        url = cr.base + "/get.php?username=" + enc(cr.u) + "&password=" + enc(cr.p) + "&type=m3u_plus&output=m3u8"
    end if
    if url = invalid or url = "" then return false
    setStatus("Baixando a lista...")
    print "NxTv tarefa: baixando lista M3U"
    setStatus("Baixando lista...")
    txt = httpGet(url, 180000)
    if txt = invalid or txt = "" then return false
    setStatus("Organizando canais...")
    lines = txt.split(chr(10))
    txt = invalid
    cur = invalid
    gl = {}
    gm = {}
    gs = {}
    for each rawLine in lines
        l = rawLine.trim()
        if l.len() < 2
            ' linha vazia: ignora
        else if l.left(1) = "#"
            if l.left(7) = "#EXTINF"
                cur = { n: "", l: "", g: "" }
                for each a in m.attr.matchAll(l)
                    k = lcase(a[1])
                    if k = "tvg-logo" then cur.l = a[2]
                    if k = "group-title" then cur.g = a[2]
                end for
                st = m.attr.replaceAll(l, "")
                ci = st.instr(",")
                if ci >= 0 then cur.n = st.mid(ci + 1).trim()
                if cur.n = "" then cur.n = "Sem nome"
            end if
        else
            if cur = invalid then cur = { n: l, l: "", g: "" }
            if cur.g = "" then cur.g = "Sem categoria"
            addM3U(cur, l, gl, gm, gs)
            cur = invalid
        end if
    end for
    lines = invalid
    if m.ch.count() = 0 then return false
    m.groups.live = gl.order
    if m.groups.live = invalid then m.groups.live = []
    finishLive()
    if gm.order <> invalid
        allM = []
        for each g in gm.order
            g.items = orderIdx(g.items, m.ch)
            allM.append(g.items)
        end for
        m.groups.movie = orderGroups(gm.order)
        m.groups.movie.unshift({ name: "Todos os filmes", items: orderIdx(allM, m.ch), adult: false, lazy: invalid })
    end if
    if gs.order <> invalid
        allS = []
        for each g in gs.order
            g.items = orderIdx(g.items, m.series)
            allS.append(g.items)
        end for
        m.groups.series = orderGroups(gs.order)
        m.groups.series.unshift({ name: "Todas as séries", items: orderIdx(allS, m.series), adult: false, lazy: invalid })
    end if
    return true
end function

sub gAdd(map as object, name as string, val as integer)
    if map.order = invalid then map.order = []
    g = map["g_" + name]
    if g = invalid
        g = { name: name, items: [], adult: isAdultTxt(name, true), lazy: invalid }
        map["g_" + name] = g
        map.order.push(g)
    end if
    g.items.push(val)
end sub

sub addM3U(cur as object, url as string, gl as object, gm as object, gs as object)
    lu = lcase(url)
    isEp = m.ep1.isMatch(cur.n)
    lg = lcase(cur.g)
    t = "live"
    if lu.instr("/series/") >= 0
        t = "series"
    else if lu.instr("/movie/") >= 0
        if isEp then t = "series" else t = "movie"
    else if m.vodExt.isMatch(lu) or isEp
        if isEp or lg.instr("serie") >= 0 or lg.instr("novela") >= 0 then t = "series" else t = "movie"
    end if
    adult = isAdultTxt(cur.g, true) or isAdultTxt(cur.n, false)
    if t = "series"
        mm = m.ep1.match(cur.n)
        title = cur.n
        se = 0
        ep = 0
        if mm.count() >= 4 and mm[1].trim() <> ""
            title = mm[1].trim()
            se = mm[2].toInt()
            ep = mm[3].toInt()
        end if
        key = "s_" + lcase(title)
        si = m.sKey[key]
        if si = invalid
            si = m.series.count()
            m.sKey[key] = si
            m.series.push({ n: title, l: cur.l, g: cur.g, eps: [], id: "", a: adult })
            gAdd(gs, cur.g, si)
        end if
        if adult then m.series[si].a = true
        m.series[si].eps.push({ n: cur.n, u: url, se: se, ep: ep, l: cur.l })
        return
    end if
    alt = ""
    if t = "live"
        if lu.right(3) = ".ts"
            alt = url
            url = url.left(url.len() - 3) + ".m3u8"
        else if CreateObject("roRegex", "/\d+$", "").isMatch(url)
            alt = url
            url = url + ".m3u8"
        end if
    end if
    idx = m.ch.count()
    m.ch.push({ n: cur.n, l: cur.l, g: cur.g, u: url, alt: alt, t: t, a: adult, sid: "" })
    if t = "live" then gAdd(gl, cur.g, idx) else gAdd(gm, cur.g, idx)
end sub

' ---------------- respostas para a tela ----------------
function newNode(title as string) as object
    n = CreateObject("roSGNode", "ContentNode")
    n.title = title
    return n
end function

sub doGroups(c as object)
    if c.sec = "events" then loadEvents()
    root = CreateObject("roSGNode", "ContentNode")
    root.addFields({ rid: c.rid, sec: c.sec, err: c.sec = "events" and m.evErr = true })
    arr = groupsOf(c.sec)
    i = 0
    for each g in arr
        it = root.createChild("ContentNode")
        it.title = g.name
        cnt = ""
        if g.items <> invalid then cnt = "(" + g.items.count().toStr() + ")"
        it.shortDescriptionLine1 = cnt
        badge = ""
        if g.adult and not c.unlocked then badge = "lock"
        it.addFields({ badge: badge, cat: i, adult: g.adult })
        i = i + 1
    end for
    m.top.outGroups = root
end sub

function groupsOf(sec as string) as object
    if sec = "fav" then return favGroups()
    if sec = "events" then return m.evGroups
    if sec = "search"
        if m.search = invalid then return []
        return m.search
    end if
    return m.groups[sec]
end function

function kindOf(sec as string, g as object) as string
    if g.kind <> invalid then return g.kind
    return sec
end function

sub doItems(c as object)
    arr = groupsOf(c.sec)
    root = CreateObject("roSGNode", "ContentNode")
    root.addFields({ rid: c.rid, sec: c.sec, cat: c.cat, locked: false, kind: "" })
    if arr = invalid or c.cat >= arr.count()
        m.top.outItems = root
        return
    end if
    g = arr[c.cat]
    if c.sec = "events"
        root.kind = "event"
        for each i in g.items
            eventNode(root, m.ev[i])
        end for
        m.top.outItems = root
        return
    end if
    kind = kindOf(c.sec, g)
    root.kind = kind
    if g.adult and not c.unlocked
        root.locked = true
        m.top.outItems = root
        return
    end if
    if g.items = invalid and g.lazy <> invalid then loadLazy(g)
    if g.items = invalid then g.items = []
    if g.meta <> invalid
        for each it in g.items
            addMetaNode(root, it)
        end for
    else if kind = "series"
        for each si in g.items
            addSeriesNode(root, si, c.unlocked)
        end for
    else
        for each i in g.items
            addChNode(root, i, kind, c.unlocked)
        end for
    end if
    m.top.outItems = root
end sub

sub addChNode(root as object, i as integer, kind as string, unlocked as boolean)
    ch = m.ch[i]
    it = root.createChild("ContentNode")
    num = ""
    if kind = "live" and ch.num <> invalid then num = ch.num.toStr()
    if ch.a and not unlocked
        it.title = "Conteúdo adulto"
        it.addFields({ num: num, badge: "lock", showLogo: false, locked: true, kind: kind })
        return
    end if
    it.title = ch.n
    it.hdPosterUrl = ch.l
    badge = ""
    if isFavUrl(ch.u) then badge = "star"
    it.addFields({ num: num, badge: badge, showLogo: true, locked: false, kind: kind, surl: ch.u, salt: ch.alt, grp: ch.g, sid: ch.sid, adult: ch.a, idx: i })
end sub

sub addSeriesNode(root as object, si as integer, unlocked as boolean)
    s = m.series[si]
    it = root.createChild("ContentNode")
    if s.a and not unlocked
        it.title = "Conteúdo adulto"
        it.addFields({ badge: "lock", showLogo: false, locked: true, kind: "series" })
        return
    end if
    it.title = s.n
    it.hdPosterUrl = s.l
    if s.eps <> invalid then it.shortDescriptionLine1 = s.eps.count().toStr() + " ep."
    badge = ""
    if isFavUrl("s:" + lcase(s.n)) then badge = "star"
    it.addFields({ badge: badge, showLogo: true, locked: false, kind: "series", sidx: si, grp: s.g, adult: s.a, seriesId: s.id, sname: s.n })
end sub

sub addMetaNode(root as object, f as object)
    it = root.createChild("ContentNode")
    it.title = f.n
    it.hdPosterUrl = f.l
    it.addFields({ badge: "star", showLogo: true, locked: false, kind: f.t, surl: f.u, salt: f.alt, grp: f.g, sid: f.sid, adult: false, sidx: -1, sname: f.n, seriesId: f.id })
end sub

sub loadLazy(g as object)
    if m.api = invalid then return
    setStatus("Carregando " + g.name + "...")
    txt = httpGet(apiUrl(g.lazy.act, "&category_id=" + enc(g.lazy.cat)), 90000)
    arr = invalid
    if txt <> invalid then arr = ParseJSON(txt)
    txt = invalid
    g.items = []
    if type(arr) <> "roArray" then return
    if g.lazy.act = "get_vod_streams"
        base = m.api.base + "/movie/" + enc(m.api.u) + "/" + enc(m.api.p) + "/"
        for each a in arr
            nm = anyStr(a.name)
            ext = anyStr(a.container_extension)
            if ext = "" then ext = "mp4"
            g.items.push(m.ch.count())
            m.ch.push({ n: nm, l: anyStr(a.stream_icon), g: g.name, u: base + anyStr(a.stream_id) + "." + ext, alt: "", t: "movie", a: g.adult or isAdultTxt(nm, false), sid: "" })
        end for
        g.items = orderIdx(g.items, m.ch)
    else
        for each a in arr
            nm = anyStr(a.name)
            key = "s_" + lcase(nm)
            si = m.sKey[key]
            if si = invalid
                si = m.series.count()
                m.sKey[key] = si
                m.series.push({ n: nm, l: anyStr(a.cover), g: g.name, eps: invalid, id: anyStr(a.series_id), a: g.adult or isAdultTxt(nm, false) })
            end if
            g.items.push(si)
        end for
        g.items = orderIdx(g.items, m.series)
    end if
    setStatus("")
end sub

' ---------------- séries: temporadas e episódios ----------------
sub doSeries(c as object)
    root = CreateObject("roSGNode", "ContentNode")
    root.addFields({ rid: c.rid, ok: false, sname: "" })
    si = c.sidx
    if si = invalid or si < 0
        ' favorito: procura pelo nome ou cria pelo id do servidor
        key = "s_" + lcase(c.sname)
        si = m.sKey[key]
        if si = invalid
            si = m.series.count()
            m.sKey[key] = si
            m.series.push({ n: c.sname, l: "", g: "", eps: invalid, id: c.seriesId, a: false })
        end if
    end if
    s = m.series[si]
    root.sname = s.n
    if s.eps = invalid then loadSeriesInfo(s)
    if s.eps = invalid or s.eps.count() = 0
        m.top.outSeries = root
        return
    end if
    ' agrupa por temporada (mantém a ordem de episódio)
    seasons = {}
    order = []
    for each e in s.eps
        k = "t" + e.se.toStr()
        if seasons[k] = invalid
            seasons[k] = { se: e.se, eps: [] }
            order.push(seasons[k])
        end if
        seasons[k].eps.push(e)
    end for
    order.sortBy("se")
    seenMap = seenOf(s.n)
    firstUnseen = invalid
    si2 = 0
    for each t in order
        t.eps.sortBy("ep")
        sn = root.createChild("ContentNode")
        if t.se > 0 then sn.title = "Temporada " + t.se.toStr() else sn.title = "Episódios"
        sn.shortDescriptionLine1 = "(" + t.eps.count().toStr() + ")"
        allSeen = true
        ei = 0
        for each e in t.eps
            en = sn.createChild("ContentNode")
            lbl = "#" + (ei + 1).toStr()
            if e.ep > 0
                lbl = "E" + e.ep.toStr()
                if e.ep < 10 then lbl = "E0" + e.ep.toStr()
            end if
            seen = seenMap[e.se.toStr() + "-" + e.ep.toStr()] = true
            if not seen
                allSeen = false
                if firstUnseen = invalid then firstUnseen = [si2, ei]
            end if
            tt = epTitle(e.n, s.n)
            en.title = tt
            en.hdPosterUrl = e.l
            badge = ""
            if seen then badge = "check"
            en.addFields({ num: lbl, badge: badge, dim: seen, showLogo: false, kind: "ep", surl: e.u, salt: "", se: e.se, ep: e.ep, sname: s.n, locked: false, epLabel: lbl })
            ei = ei + 1
        end for
        badge = ""
        if allSeen then badge = "check"
        sn.addFields({ badge: badge })
        si2 = si2 + 1
    end for
    if firstUnseen = invalid then firstUnseen = [0, 0]
    root.addFields({ startSeason: firstUnseen[0], startEp: firstUnseen[1], poster: s.l })
    root.ok = true
    m.top.outSeries = root
end sub

function epTitle(name as string, sname as string) as string
    t = name
    if lcase(t).instr(lcase(sname)) = 0 then t = t.mid(sname.len())
    mm = m.epStrip.match(t)
    if mm.count() > 0 then t = t.mid(mm[0].len())
    t = t.trim()
    while t.len() > 0 and instr(1, "-:|. ", t.left(1)) > 0
        t = t.mid(1)
    end while
    if t = "" then t = "Episódio"
    return t
end function

sub loadSeriesInfo(s as object)
    if m.api = invalid or s.id = "" then return
    setStatus("Carregando episódios...")
    txt = httpGet(apiUrl("get_series_info", "&series_id=" + enc(s.id)), 90000)
    d = invalid
    if txt <> invalid then d = ParseJSON(txt)
    s.eps = []
    if d = invalid or d.episodes = invalid then return
    base = m.api.base + "/series/" + enc(m.api.u) + "/" + enc(m.api.p) + "/"
    E = d.episodes
    if type(E) = "roAssociativeArray"
        for each k in E
            addEps(s, E[k], k.toInt(), base)
        end for
    else if type(E) = "roArray"
        i = 1
        for each lst in E
            addEps(s, lst, i, base)
            i = i + 1
        end for
    end if
    setStatus("")
end sub

sub addEps(s as object, lst as dynamic, seDef as integer, base as string)
    if type(lst) <> "roArray" then return
    i = 1
    for each e in lst
        se = anyInt(e.season)
        if se = 0 then se = seDef
        ep = anyInt(e.episode_num)
        if ep = 0 then ep = i
        ext = anyStr(e.container_extension)
        if ext = "" then ext = "mp4"
        logo = s.l
        if e.info <> invalid and type(e.info) = "roAssociativeArray" and e.info.movie_image <> invalid then logo = anyStr(e.info.movie_image)
        s.eps.push({ n: anyStr(e.title), u: base + anyStr(e.id) + "." + ext, se: se, ep: ep, l: logo })
        i = i + 1
    end for
end sub

' ---------------- pesquisa ----------------
sub doSearch(c as object)
    q = lcase(c.q.trim())
    live = []
    mov = []
    ser = []
    MAXR = 300
    i = 0
    for each ch in m.ch
        if (c.unlocked or not ch.a) and lcase(ch.n).instr(q) >= 0
            if ch.t = "live" and live.count() < MAXR then live.push(i)
            if ch.t = "movie" and mov.count() < MAXR then mov.push(i)
        end if
        i = i + 1
    end for
    i = 0
    for each s in m.series
        if (c.unlocked or not s.a) and lcase(s.n).instr(q) >= 0 and ser.count() < MAXR then ser.push(i)
        i = i + 1
    end for
    ' servidor Xtream: procura também nas categorias de filmes e séries ainda não abertas
    if m.api <> invalid
        total = 0
        for each g in m.groups.movie
            if g.items = invalid then total = total + 1
        end for
        for each g in m.groups.series
            if g.items = invalid then total = total + 1
        end for
        done = 0
        for each g in m.groups.movie
            if g.items = invalid and (c.unlocked or not g.adult)
                done = done + 1
                setStatus("Buscando em filmes e séries " + done.toStr() + "/" + total.toStr() + "...")
                scanLazy(g, q, mov, ser, c.unlocked, MAXR)
            end if
        end for
        for each g in m.groups.series
            if g.items = invalid and (c.unlocked or not g.adult)
                done = done + 1
                setStatus("Buscando em filmes e séries " + done.toStr() + "/" + total.toStr() + "...")
                scanLazy(g, q, mov, ser, c.unlocked, MAXR)
            end if
        end for
        setStatus("")
    end if
    m.search = [{ name: "TV ao Vivo", items: live, adult: false, kind: "live" }, { name: "Filmes", items: dedupe(mov), adult: false, kind: "movie" }, { name: "Séries", items: dedupe(ser), adult: false, kind: "series" }]
    doGroups({ rid: c.rid, sec: "search", unlocked: c.unlocked })
end sub

function dedupe(a as object) as object
    seen = {}
    out = []
    for each v in a
        k = "k" + v.toStr()
        if seen[k] = invalid
            seen[k] = true
            out.push(v)
        end if
    end for
    return out
end function

' baixa uma categoria só para procurar o nome, guardando apenas o que combina (economiza memória)
sub scanLazy(g as object, q as string, mov as object, ser as object, unlocked as boolean, MAXR as integer)
    txt = httpGet(apiUrl(g.lazy.act, "&category_id=" + enc(g.lazy.cat)), 60000)
    if txt = invalid then return
    arr = ParseJSON(txt)
    txt = invalid
    if type(arr) <> "roArray" then return
    if g.lazy.act = "get_vod_streams"
        base = m.api.base + "/movie/" + enc(m.api.u) + "/" + enc(m.api.p) + "/"
        for each a in arr
            nm = anyStr(a.name)
            if mov.count() < MAXR and lcase(nm).instr(q) >= 0
                ad = g.adult or isAdultTxt(nm, false)
                if unlocked or not ad
                    ext = anyStr(a.container_extension)
                    if ext = "" then ext = "mp4"
                    mov.push(m.ch.count())
                    m.ch.push({ n: nm, l: anyStr(a.stream_icon), g: g.name, u: base + anyStr(a.stream_id) + "." + ext, alt: "", t: "movie", a: ad, sid: "" })
                end if
            end if
        end for
    else
        for each a in arr
            nm = anyStr(a.name)
            if ser.count() < MAXR and lcase(nm).instr(q) >= 0
                key = "s_" + lcase(nm)
                si = m.sKey[key]
                if si = invalid
                    si = m.series.count()
                    m.sKey[key] = si
                    m.series.push({ n: nm, l: anyStr(a.cover), g: g.name, eps: invalid, id: anyStr(a.series_id), a: g.adult or isAdultTxt(nm, false) })
                end if
                if unlocked or not m.series[si].a then ser.push(si)
            end if
        end for
    end if
end sub

' ---------------- programação (EPG) ----------------
sub doEpg(c as object)
    res = { rid: c.rid, now: "", time: "", pct: 0, nxt: "", ok: false }
    if m.api = invalid or c.sid = invalid or c.sid = ""
        m.top.outEpg = res
        return
    end if
    txt = httpGet(apiUrl("get_short_epg", "&stream_id=" + c.sid + "&limit=4"), 10000)
    d = invalid
    if txt <> invalid then d = ParseJSON(txt)
    if d = invalid or d.epg_listings = invalid
        m.top.outEpg = res
        return
    end if
    now = CreateObject("roDateTime").asSeconds()
    cur = invalid
    nxt = invalid
    lst = d.epg_listings
    for i = 0 to lst.count() - 1
        e = lst[i]
        st = anyInt(e.start_timestamp)
        en = anyInt(e.stop_timestamp)
        if cur = invalid and st <= now and now < en
            cur = { t: b64(anyStr(e.title)), s: st, e: en }
            if i + 1 < lst.count()
                n2 = lst[i + 1]
                nxt = { t: b64(anyStr(n2.title)), s: anyInt(n2.start_timestamp) }
            end if
        end if
    end for
    if cur <> invalid
        res.ok = true
        res.now = cur.t
        res.time = hhmm(cur.s) + " - " + hhmm(cur.e)
        if cur.e > cur.s then res.pct = (now - cur.s) / (cur.e - cur.s)
    end if
    if nxt <> invalid then res.nxt = hhmm(nxt.s) + " · " + nxt.t
    m.top.outEpg = res
end sub

function b64(s as string) as string
    if s = "" then return ""
    ba = CreateObject("roByteArray")
    ba.fromBase64String(s)
    return ba.toAsciiString()
end function

function hhmm(sec as integer) as string
    d = CreateObject("roDateTime")
    d.fromSeconds(sec)
    d.toLocalTime()
    h = d.getHours()
    mi = d.getMinutes()
    hs = h.toStr()
    if h < 10 then hs = "0" + hs
    ms = mi.toStr()
    if mi < 10 then ms = "0" + ms
    return hs + ":" + ms
end function

' ---------------- favoritos ----------------
function favList() as object
    if m.favs = invalid
        t = m.reg.read("favs")
        m.favs = invalid
        if t <> "" then m.favs = ParseJSON(t)
        if type(m.favs) <> "roArray" then m.favs = []
    end if
    return m.favs
end function

function isFavUrl(k as string) as boolean
    for each f in favList()
        if f.k = k then return true
    end for
    return false
end function

sub doFav(c as object)
    lst = favList()
    fpos = -1
    for i = 0 to lst.count() - 1
        if lst[i].k = c.f.k then fpos = i
    end for
    if fpos >= 0
        lst.delete(fpos)
    else
        if lst.count() >= 80 then lst.delete(0)
        lst.push(c.f)
    end if
    m.reg.write("favs", FormatJSON(lst))
    m.reg.flush()
end sub

function favGroups() as object
    live = []
    mov = []
    ser = []
    for each f in favList()
        if f.t = "live" then live.push(f)
        if f.t = "movie" then mov.push(f)
        if f.t = "series" then ser.push(f)
    end for
    return [{ name: "Canais", items: live, adult: false, kind: "live", meta: true }, { name: "Filmes", items: mov, adult: false, kind: "movie", meta: true }, { name: "Séries", items: ser, adult: false, kind: "series", meta: true }]
end function

' ---------------- episódios assistidos ----------------
function seenAll() as object
    if m.seen = invalid
        t = m.reg.read("seen")
        m.seen = invalid
        if t <> "" then m.seen = ParseJSON(t)
        if type(m.seen) <> "roAssociativeArray" then m.seen = {}
    end if
    return m.seen
end function

function seenOf(sname as string) as object
    out = {}
    v = seenAll()[lcase(sname)]
    if v <> invalid
        for each p in v.split(",")
            if p <> "" then out[p] = true
        end for
    end if
    return out
end function

sub doSeen(c as object)
    all = seenAll()
    k = lcase(c.sname)
    v = all[k]
    if v = invalid then v = ""
    tag = c.se.toStr() + "-" + c.ep.toStr()
    if ("," + v + ",").instr("," + tag + ",") >= 0 then return
    if v = "" then v = tag else v = v + "," + tag
    all[k] = v
    if all.count() > 120
        for each kk in all
            if kk <> k
                all.delete(kk)
                exit for
            end if
        end for
    end if
    m.reg.write("seen", FormatJSON(all))
    m.reg.flush()
end sub

' ================= Eventos do dia (placar público da ESPN) =================
function evLeagues() as object
    return [
        ["soccer", "bra.1", "Brasileirão Série A"], ["soccer", "bra.2", "Brasileirão Série B"], ["soccer", "bra.copa_do_brazil", "Copa do Brasil"],
        ["soccer", "bra.camp.paulista", "Paulistão"], ["soccer", "bra.camp.carioca", "Carioca"], ["soccer", "bra.camp.mineiro", "Mineiro"],
        ["soccer", "bra.camp.gaucho", "Gauchão"], ["soccer", "bra.supercopa_do_brazil", "Supercopa do Brasil"],
        ["soccer", "conmebol.libertadores", "Libertadores"], ["soccer", "conmebol.sudamericana", "Sul-Americana"], ["soccer", "conmebol.recopa", "Recopa"],
        ["soccer", "fifa.worldq.conmebol", "Eliminatórias"], ["soccer", "fifa.world", "Copa do Mundo"], ["soccer", "fifa.cwc", "Mundial de Clubes"],
        ["soccer", "fifa.intercontinental_cup", "Copa Intercontinental"], ["soccer", "fifa.friendly", "Amistosos de seleções"], ["soccer", "conmebol.america", "Copa América"],
        ["soccer", "uefa.champions", "Champions League"], ["soccer", "uefa.europa", "Europa League"], ["soccer", "uefa.europa.conf", "Conference League"],
        ["soccer", "eng.1", "Premier League"], ["soccer", "esp.1", "LaLiga"], ["soccer", "ita.1", "Série A Italiana"], ["soccer", "ger.1", "Bundesliga"],
        ["soccer", "fra.1", "Ligue 1"], ["soccer", "por.1", "Liga Portugal"], ["soccer", "arg.1", "Argentino"], ["soccer", "ksa.1", "Liga Saudita"],
        ["soccer", "usa.1", "MLS"], ["soccer", "eng.fa", "Copa da Inglaterra"], ["soccer", "esp.copa_del_rey", "Copa do Rei"],
        ["mma", "ufc", "UFC"], ["basketball", "nba", "NBA"], ["football", "nfl", "NFL"], ["racing", "f1", "Fórmula 1"]
    ]
end function

function pad2(n as integer) as string
    if n < 10 then return "0" + n.toStr()
    return n.toStr()
end function

' "2026-11-21T22:30Z" -> segundos (UTC)
function isoSecs(s as dynamic) as integer
    if s = invalid or type(s) <> "roString" and type(s) <> "String" then return 0
    t = s
    if t.right(1) = "Z" then t = t.left(t.len() - 1)
    if t.len() = 16 then t = t + ":00"
    d = CreateObject("roDateTime")
    d.fromISO8601String(t)
    return d.asSeconds()
end function

function localDt(secs as integer) as object
    d = CreateObject("roDateTime")
    d.fromSeconds(secs)
    d.toLocalTime()
    return d
end function

function dayKey(secs as integer) as string
    d = localDt(secs)
    return d.getYear().toStr() + pad2(d.getMonth()) + pad2(d.getDayOfMonth())
end function

function hmOf(secs as integer) as string
    d = localDt(secs)
    return pad2(d.getHours()) + ":" + pad2(d.getMinutes())
end function

function todayKey() as string
    d = CreateObject("roDateTime")
    return dayKey(d.asSeconds())
end function

' logotipo em tamanho menor (servidor de imagens da ESPN)
function smallLogo(u as dynamic, sz as integer) as string
    if u = invalid or u = "" then return ""
    p = ""
    i = u.instr("a.espncdn.com/i/")
    if i >= 0
        p = u.mid(i + 13)
        q = p.instr("?")
        if q >= 0 then p = p.left(q)
    else
        i = u.instr("img=/i/")
        if i >= 0
            p = u.mid(i + 4)
            q = p.instr("&")
            if q >= 0 then p = p.left(q)
        end if
    end if
    if p = "" then return u
    return "https://a.espncdn.com/combiner/i?img=" + p + "&w=" + sz.toStr() + "&h=" + sz.toStr()
end function

function sv(v as dynamic) as string
    if v = invalid then return ""
    if type(v) = "roString" or type(v) = "String" then return v
    if type(v) = "roInt" or type(v) = "Integer" or type(v) = "roFloat" or type(v) = "Float" or type(v) = "Double" then return v.toStr()
    return ""
end function

' baixa várias páginas ao mesmo tempo (até 6)
function httpMulti(urls as object, timeoutMs as integer) as object
    port = CreateObject("roMessagePort")
    res = []
    for i = 0 to urls.count() - 1
        res.push(invalid)
    end for
    jobs = {}
    nextI = 0
    running = 0
    clock = CreateObject("roTimespan")
    while nextI < urls.count() or running > 0
        while running < 6 and nextI < urls.count()
            x = CreateObject("roUrlTransfer")
            x.setMessagePort(port)
            x.setUrl(urls[nextI])
            x.setCertificatesFile("common:/certs/ca-bundle.crt")
            x.initClientCertificates()
            x.enableEncodings(true)
            if x.asyncGetToString()
                jobs[x.getIdentity().toStr()] = { x: x, i: nextI }
                running = running + 1
            end if
            nextI = nextI + 1
        end while
        if running = 0 then exit while
        ev = wait(1000, port)
        if type(ev) = "roUrlEvent"
            jk = ev.getSourceIdentity().toStr()
            j = jobs[jk]
            if j <> invalid
                if ev.getResponseCode() = 200 then res[j.i] = ev.getString()
                jobs.delete(jk)
                running = running - 1
            end if
        end if
        if clock.totalMilliseconds() > timeoutMs then exit while
    end while
    for each k in jobs
        jobs[k].x.asyncCancel()
    end for
    return res
end function

sub loadEvents()
    today = todayKey()
    now = CreateObject("roDateTime").asSeconds()
    if m.evAt = invalid then m.evAt = 0
    if m.evDay = invalid then m.evDay = ""
    if m.evDay = today and now - m.evAt < 120 and m.evGroups <> invalid then return
    setStatus("Buscando os jogos de hoje...")
    L = evLeagues()
    urls = []
    for each lg in L
        urls.push("https://site.api.espn.com/apis/site/v2/sports/" + lg[0] + "/" + lg[1] + "/scoreboard?dates=" + today)
    end for
    pages = httpMulti(urls, 30000)
    out = []
    ok = 0
    for i = 0 to L.count() - 1
        if pages[i] <> invalid
            ok = ok + 1
            j = ParseJSON(pages[i])
            if j <> invalid then parseEvents(L[i], i, j, today, out)
        end if
    end for
    pages = invalid
    out.sortBy("t")
    m.ev = out
    m.evDay = today
    m.evAt = now
    m.evErr = (ok = 0)
    ' categorias: todos, ao vivo e uma por campeonato (na ordem da lista acima)
    allI = []
    liveI = []
    byL = {}
    for i = 0 to out.count() - 1
        e = out[i]
        allI.push(i)
        if e.state = "in" then liveI.push(i)
        k = "L" + e.lix.toStr()
        if byL[k] = invalid then byL[k] = { name: e.league, lix: e.lix, items: [] }
        byL[k].items.push(i)
    end for
    groups = [{ name: "Todos", items: allI, adult: false, kind: "event" }]
    if liveI.count() > 0 then groups.push({ name: "Ao vivo agora", items: liveI, adult: false, kind: "event" })
    for i = 0 to L.count() - 1
        g = byL["L" + i.toStr()]
        if g <> invalid then groups.push({ name: g.name, items: g.items, adult: false, kind: "event" })
    end for
    m.evGroups = groups
    setStatus("")
end sub

function f1Session(ab as string) as string
    names = { FP1: "Treino livre 1", FP2: "Treino livre 2", FP3: "Treino livre 3", Qual: "Classificação", Race: "Corrida", SS: "Sprint classificação", SQ: "Sprint classificação", Sprint: "Corrida sprint" }
    if names.doesExist(ab) then return names[ab]
    if ab = "" then return "Sessão"
    return ab
end function

function f1Name(n as string) as string
    r = CreateObject("roRegex", "^.*?(\w+(?: \w+)?) Grand Prix$", "i")
    mm = r.match(n)
    if mm.count() > 1 then return "GP " + mm[1]
    return n
end function

sub parseEvents(L as object, lix as integer, j as object, today as string, out as object)
    evs = j.events
    if evs = invalid then return
    llogo = ""
    if j.leagues <> invalid and j.leagues.count() > 0
        lg = j.leagues[0]
        if lg.logos <> invalid and lg.logos.count() > 0 then llogo = sv(lg.logos[0].href)
    end if
    for each e in evs
        st = {}
        if e.status <> invalid and e.status.type <> invalid then st = e.status.type
        base = { league: L[2], lix: lix, llogo: llogo, home: "", away: "", hlogo: "", alogo: "", hscore: "", ascore: "", state: sv(st.state), detail: sv(st.shortDetail), venue: "", title: "", subt: "", q: "" }
        cps = e.competitions
        if cps = invalid then cps = []
        if L[0] = "racing"
            for each cp in cps
                t = isoSecs(cp.date)
                if t > 0 and dayKey(t) = today
                    o = {}
                    o.append(base)
                    cst = st
                    if cp.status <> invalid and cp.status.type <> invalid then cst = cp.status.type
                    ab = ""
                    if cp.type <> invalid then ab = sv(cp.type.abbreviation)
                    o.t = t
                    o.title = f1Name(sv(e.name))
                    o.subt = f1Session(ab)
                    o.state = sv(cst.state)
                    o.detail = sv(cst.shortDetail)
                    if e.circuit <> invalid then o.venue = sv(e.circuit.fullName)
                    o.q = "F1"
                    out.push(o)
                end if
            end for
        else if L[0] = "mma"
            first = 0
            for each cp in cps
                t = isoSecs(cp.date)
                if t > 0 and dayKey(t) = today and first = 0 then first = t
            end for
            if first = 0
                t = isoSecs(e.date)
                if t > 0 and dayKey(t) = today then first = t
            end if
            if first > 0
                o = {}
                o.append(base)
                o.t = first
                o.title = sv(e.name)
                o.q = "UFC"
                if cps.count() > 0
                    mainF = cps[cps.count() - 1]
                    o.subt = "Luta principal " + hmOf(isoSecs(mainF.date)) + " · " + cps.count().toStr() + " lutas"
                    fs = mainF.competitors
                    if fs <> invalid and fs.count() >= 2
                        a1 = fs[0].athlete
                        a2 = fs[1].athlete
                        if a1 <> invalid and a2 <> invalid
                            o.home = sv(a1.displayName)
                            o.away = sv(a2.displayName)
                            if a1.flag <> invalid then o.hlogo = sv(a1.flag.href)
                            if a2.flag <> invalid then o.alogo = sv(a2.flag.href)
                        end if
                    end if
                end if
                out.push(o)
            end if
        else
            t = isoSecs(e.date)
            if t > 0 and dayKey(t) = today and cps.count() > 0
                cp0 = cps[0]
                h = invalid
                a = invalid
                if cp0.competitors <> invalid
                    for each c in cp0.competitors
                        if c.homeAway = "home" then h = c else a = c
                    end for
                end if
                if h <> invalid and a <> invalid and h.team <> invalid and a.team <> invalid
                    o = {}
                    o.append(base)
                    o.t = t
                    o.home = sv(h.team.shortDisplayName)
                    if o.home = "" then o.home = sv(h.team.displayName)
                    o.away = sv(a.team.shortDisplayName)
                    if o.away = "" then o.away = sv(a.team.displayName)
                    o.hlogo = sv(h.team.logo)
                    o.alogo = sv(a.team.logo)
                    o.hscore = sv(h.score)
                    o.ascore = sv(a.score)
                    if cp0.venue <> invalid then o.venue = sv(cp0.venue.fullName)
                    o.q = o.home
                    out.push(o)
                end if
            end if
        end if
    end for
end sub

sub eventNode(root as object, e as object)
    n = root.createChild("ContentNode")
    hm = hmOf(e.t)
    if e.home <> ""
        n.title = e.home + " x " + e.away
        n.hdPosterUrl = smallLogo(e.hlogo, 80)
    else
        n.title = e.title
        if e.subt <> "" then n.title = e.title + " · " + e.subt
        n.hdPosterUrl = smallLogo(e.llogo, 80)
    end if
    stTxt = ""
    sc = ""
    if e.home <> "" and e.hscore <> "" then sc = e.hscore + "x" + e.ascore + " "
    if e.state = "in"
        d = e.detail
        if d.len() > 8 then d = "AO VIVO"
        stTxt = sc + d
    else if e.state = "post"
        stTxt = sc + "Fim"
    end if
    n.shortDescriptionLine1 = stTxt
    evTitle = ""
    if e.home <> "" and e.title <> "" then evTitle = e.title
    if e.home = "" then evTitle = e.title
    n.addFields({ kind: "event", num: hm, showLogo: true, league: e.league, llogo: smallLogo(e.llogo, 64), llogoBig: smallLogo(e.llogo, 200),
        hlogoBig: smallLogo(e.hlogo, 200), alogoBig: smallLogo(e.alogo, 200), home: e.home, away: e.away, hscore: e.hscore, ascore: e.ascore,
        state: e.state, detail: e.detail, venue: e.venue, subt: e.subt, evTitle: evTitle, q: e.q })
end sub

' ================= atualização do app =================
sub doUpd()
    base = "https://raw.githubusercontent.com/Nxiptvideo/nxtv/main/"
    tag = CreateObject("roDateTime").asSeconds()
    if base.instr("__") >= 0
        m.top.outUpd = { ok: false, n: tag }
        return
    end if
    txt = httpGet(base + "version.json?t=" + tag.toStr(), 20000)
    j = invalid
    if txt <> invalid and txt <> "" then j = ParseJSON(txt)
    if j = invalid or j.roku = invalid or j.roku.ver = invalid
        m.top.outUpd = { ok: false, n: tag }
        return
    end if
    zip = "roku/NxTvLib.zip"
    if j.roku.zip <> invalid then zip = j.roku.zip
    m.top.outUpd = { ok: true, ver: j.roku.ver, zip: base + zip, n: tag }
end sub
